<?php
require_once(dirname(__FILE__) . "/include/common.inc.php");

$dsql->safeCheck = false; //关闭安全检查
sqlModify();

function sqlModify()
{
    global $dsql;
	
    $sql1="alter table sline_admin add column beizu varchar(500);";
  
 
    $dsql->ExecuteNoneQuery($sql1);
  
   

}









