<?php defined('SYSPATH') or die('No direct access allowed.');

class Model_Member_Order extends ORM {


    /*
     * 返积分操作
     * */
    public static function refundJifen($orderid)
    {
        $row = ORM::factory('member_order')->where('id='.$orderid)->find()->as_array();
        if(isset($row))
        {
            $memberid = $row['memberid'];
            $jifenbook = intval($row['jifenbook']);
            $member = ORM::factory('member')->where("mid=$memberid");
            $member->jifen = intval($member->jifen) + $jifenbook;
            $member->save();
            if($member->saved())
            {
                $memberid = $member->mid;
                $content = "预订{$row['productname']}获得{$jifenbook}积分";
                self::addJifenLog($memberid,$content,$jifenbook,2);
            }

        }

    }

    public static function addJifenLog($memberid,$content,$jifen,$type)
    {
        $addtime = time();
        $sql = "insert into sline_member_jifen_log(memberid,content,jifen,`type`,addtime) values ('$memberid','$content','$jifen','$type','$addtime')";
        DB::query(Database::INSERT,$sql)->execute();

    }


}