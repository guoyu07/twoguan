<?php defined('SYSPATH') or die('No direct script access.');
class Controller_Upgrade extends Stourweb_Controller{
    /*
     * 增值应用
     * */
    public function before()
    {
        parent::before();

        $this->assign('parentkey',$this->params['parentkey']);
        $this->assign('itemid',$this->params['itemid']);
    }

    //系统升级
    public function action_upgrade()
    {
        include(Kohana::find_file('data','version'));
        include(Kohana::find_file('data','license'));
        Common::sendInfo();
        $this->assign('version','思途CMS'.$cVersion.$versiontype);
        $this->assign('licenseid',$SerialNumber);
        $this->display('stourtravel/app/upgrade');
    }

    //ajax检测更新( 首页使用)
    public function action_ajax_check_update()
    {
        $model = new Model_Upgrade3();
        $out = array();
        $info = $model->getNewVersion();
        if($info['Success']==1)
        {
            $newinfo['desc'] = $info['Data'][0]['Description'];
            $newinfo['pubdate'] = Common::myDate('Y-m-d',strtotime($info['Data'][0]['ReleaseDate']));
            $newinfo['version'] = $info['Data'][0]['Version'];
            $out['newinfo'] = $newinfo;
        }
        $out['myversion'] = $model->getMyVersion();
        echo json_encode($out);


    }
    //ajax检测版本权限
    public function action_ajax_check_right()
    {
        $model = new Model_Upgrade3();
        $status=$model->checkRightV();
        $out = array('status'=>$status);

        echo json_encode($out);

    }



    //检测是否有写入权限
    public function action_ajax_checkdir()
    {

        $flag = 0;
        $filename = BASEPATH.'/stcms.txt';
        $fp=@fopen($filename,'w');
        if($fp)
        {

            @fclose($fp);
            @unlink($filename);
            $flag = 1;

        }
        echo json_encode(array('status'=>$flag));
    }



    public function action_test()
    {
        //$model = new Model_Upgrade3();
        //$version = $model->getNewVersion();
        $flag = Common::http('http://www.lvyou.com/sql.php');
        echo $flag;



    }





    //绑定授权ID
    public function action_bind()
    {
        include(Kohana::find_file('data','license'));
        $this->assign('licenseid',$SerialNumber);
        $this->display('stourtravel/app/bind');
    }
    //绑定ID
    public function action_ajax_bind_license()
    {
        $licenseid = Arr::get($_POST,'licenseid');
        $weburl = Arr::get($_POST,'weburl');
        $model = new Model_Upgrade();
        $flag = $model->checkLicense($weburl,$licenseid);
        if($flag)
        {
            Model_Upgrade::rewriteLicense($licenseid);
            echo json_encode(array('status'=>'ok'));
        }
        else
        {
            echo json_encode(array('status'=>'false'));
        }
    }



    //更新配置函数
    public function rewriteCache()
    {

        $configfile=SLINEDATA.'/autotitle.cache.inc.php';


        $fp = fopen($configfile,'w');
        flock($fp,3);
        fwrite($fp,"<"."?php\r\n");
        $sql="SELECT `name`,`value` FROM `sline_plugin_autotitle`  ORDER BY id ASC";
        $arr = DB::query(1,$sql)->execute()->as_array();
        foreach($arr as $row)
        {

            fwrite($fp,"\${$row['name']} = '".str_replace("'",'',$row['value'])."';\r\n");

        }
        fwrite($fp,"?".">");
        fclose($fp);
    }










}