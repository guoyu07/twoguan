<?php
require_once(dirname(__FILE__) . "/include/common.inc.php");
//require_once(dirname(__FILE__)."/include/file.class.php");

$dsql->safeCheck = false; //关闭安全检查
addTable();



function addTable()
{
    global $dsql;
    $sql1 = "CREATE TABLE IF NOT EXISTS `sline_model_archive` (
  `id` int(11) NOT NULL auto_increment COMMENT '自增id',
  `webid` int(11) NOT NULL default '1' COMMENT '站点ID',
  `aid` int(11) unsigned default NULL COMMENT '前台访问aid',
  `typeid` int(11) unsigned default NULL COMMENT '模型id',
  `title` varchar(255) default NULL COMMENT '标题',
  `seotitle` varchar(255) default NULL COMMENT '优化标题',
  `content` longtext COMMENT '文章内容',
  `piclist` text COMMENT '图片列表',
  `price` varchar(255) default '0' COMMENT '价格',
  `litpic` varchar(255) default NULL COMMENT '封面图片',
  `addtime` int(10) unsigned default NULL COMMENT '添加时间',
  `modtime` int(10) unsigned default NULL COMMENT '更新时间',
  `shownum` int(11) default NULL COMMENT '浏览次数',
  `tagword` varchar(50) default NULL COMMENT 'tag词',
  `keyword` varchar(50) default NULL COMMENT '关键词',
  `description` varchar(500) default NULL COMMENT '描述',
  `kindlist` varchar(255) default NULL COMMENT '目的地id',
  `themelist` varchar(255) default NULL COMMENT '专题id',
  `attrid` varchar(255) default NULL COMMENT '属性id',
  `ishidden` tinyint(4) default '0' COMMENT '是否隐藏',
  `iconlist` varchar(255) default NULL COMMENT '图标id',
  `templet` varchar(255) default NULL COMMENT '使用模板',
  `satisfyscore` varchar(255) default NULL COMMENT '满意度',
  `sellpoint` varchar(255) default NULL COMMENT '卖点',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='扩展信息表';";


    $sql2 = "CREATE TABLE IF NOT EXISTS `sline_model_attr` (
  `id` int(11) NOT NULL auto_increment,
  `webid` int(11) NOT NULL default '0' COMMENT '站点id',
  `typeid` int(11) NOT NULL COMMENT '模型id',
  `attrname` varchar(255) default NULL,
  `displayorder` int(4) unsigned default '9999',
  `isopen` int(11) unsigned default '0',
  `issystem` int(11) unsigned default '0',
  `pid` int(10) default NULL,
  `destid` varchar(255) default NULL,
  `litpic` varchar(255) default NULL,
  `description` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='扩展模块属性表';";
	$sql3 = "CREATE TABLE IF NOT EXISTS `sline_model_suit` (
  `id` int(11) NOT NULL auto_increment,
  `productid` int(11) NOT NULL COMMENT '产品id',
  `suitname` varchar(255) default NULL COMMENT '套餐名称',
  `description` text COMMENT '描述',
  `displayorder` int(11) default '9999' COMMENT '排序',
  `jifenbook` int(11) default '0' COMMENT '预订送积分',
  `jifentprice` int(11) default '0' COMMENT '积分抵现金',
  `jifencomment` int(11) default '0' COMMENT '评论送积分',
  `paytype` tinyint(1) unsigned default '1' COMMENT '支付类型',
  `number` int(11) default '-1' COMMENT '库存',
  `dingjin` varchar(255) default NULL COMMENT '定金',
  `sellprice` varchar(255) default NULL COMMENT '市场价格',
  `ourprice` varchar(255) default NULL COMMENT '本站价格',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;";

    $sql4 = "CREATE TABLE IF NOT EXISTS `sline_model` (
  `id` int(10) unsigned NOT NULL auto_increment COMMENT '模型id',
  `modulename` varchar(255) default NULL COMMENT '模块名称',
  `pinyin` varchar(255) default NULL COMMENT '拼音标识',
  `maintable` varchar(255) default NULL COMMENT '主表',
  `addtable` varchar(255) default NULL COMMENT '附加表',
  `attrtable` varchar(255) default 'model_attr' COMMENT '属性表',
  `issystem` int(1) default '0' COMMENT '是否系统',
  `isopen` int(1) default '1' COMMENT '是否开启',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `pinyin` (`pinyin`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='思途模型表';";

   $sql5="INSERT INTO `sline_model` (`id`, `modulename`, `pinyin`, `maintable`, `addtable`, `attrtable`, `issystem`, `isopen`) VALUES
	(1, '线路', 'line', 'line', 'line_extend_field', 'line_attr', 1, 1),
	(2, '酒店', 'hotel', 'hotel', 'hotel_extend_field', 'hotel_attr', 1, 1),
	(3, '租车', 'car', 'car', 'car_extend_field', 'car_attr', 1, 1),
	(4, '文章', 'article', 'article', 'article_extend_field', 'article_attr', 1, 1),
	(5, '景点', 'spot', 'spot', 'spot_extend_field', 'spot_attr', 1, 1),
	(6, '相册', 'photo', 'photo', 'photo_extend_field', 'photo_attr', 1, 1),
	(8, '签证', 'visa', 'visa', 'visa_extend_field', 'null', 1, 1),
	(13, '团购', 'tuan', 'tuan', 'tuan_extend_field', 'tuan_attr', 1, 1);";

   /* if(!checkColumn('sline_plugin_leftnav','litpic'))
    {
        $dsql->ExecuteNoneQuery($sql2);
    }
    


    if(!checkColumn('sline_plugin_leftnav','litpic'))
    {
        $dsql->ExecuteNoneQuery($sql2);
    }
    if(!checkColumn('sline_plugin_leftnav','remark'))
    {
        $dsql->ExecuteNoneQuery($sql3);
    }
	 if(!checkColumn('sline_article','summary'))
    {
        $dsql->ExecuteNoneQuery($sql4);
    } */
	$dsql->ExecuteNoneQuery($sql1);
	$dsql->ExecuteNoneQuery($sql2);
	$dsql->ExecuteNoneQuery($sql3);
	$dsql->ExecuteNoneQuery($sql4);
    $dsql->ExecuteNoneQuery($sql5);
	





}
function checkColumn($table,$column)
{
    global $dsql;
    $sql = "show columns from `{$table}` like '$column'";
    $row = $dsql->GetOne($sql);
    return isset($row['Field']) ? 1 : 0;
}

function checkTable($table)
{
    global $dsql;
    $sql = "SHOW TABLES LIKE '$table'";
    $row = $dsql->getAll($sql);
    return count($row) ? 1 : 0;

}












