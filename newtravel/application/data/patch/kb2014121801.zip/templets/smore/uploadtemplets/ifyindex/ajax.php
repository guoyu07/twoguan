<?php
require_once(dirname(dirname(dirname(dirname(dirname(__FILE__)))))."/include/common.inc.php");

if($dopost=='LoginStatus')
{
    if($User->IsLogin())
    {

        $userinfo=$User->getInfoByMid($User->uid);
        $uname = $userinfo['nickname'];//昵称
        $jifen=!empty($userinfo['jifen']) ? $userinfo['jifen'] : 0;

        $out.='<li><a href="'. $GLOBALS['cfg_cmsurl'].'/member/">'.$uname.'</a>|</li>
          <li><a href="'.$GLOBALS['cfg_cmsurl'].'/member/login.php?dopost=logout">退出</a></li>
          '  ;



    }
    else //未登陆状态
    {
        $out.='<li><a href="/member/login.php">登陆</a>|</li>
          <li><a href="/member/reg.php">免费注册</a></li>'  ;

    }

    echo $out;
    exit();

}

if($dopost=='getnation')
{
    $sql = "select id from sline_visa_area where kindname like '%$keyword%'";

    $row = $dsql->GetOne($sql);
    echo $row['id'] ? $row['id'] : 0;
}

//检测是否登陆
if($dopost=='checkLogin')
{
    $flag=0;

    if($User->isLogin())
    {

        $flag=1;
    }
    echo $flag;
    exit;

}

?>