<?php
if(!defined('SLINEINC'))
{
    exit("Request Error!");
}
/**
 * 调用线路数据标签
 *
 * @version        $Id: getline.lib.php netman
 * @package        Stourweb.Taglib
 * @copyright      Copyright (c) 2008 - 2014, Stourweb, Inc.
 * @link           http://www.stourweb.com
 */
function lib_getline(&$ctag,&$refObj)
{
    global $dsql;
	include(SLINEDATA."/webinfo.php");
    $attlist="row|8,flag|,type|top,sonid|,limit|0,";
    FillAttsDefault($ctag->CAttribute->Items,$attlist);
    extract($ctag->CAttribute->Items, EXTR_SKIP);
    $webid=0;
    $innertext = trim($ctag->GetInnertext());
    $revalue = '';
	$basefield = "a.aid,a.id,a.webid,a.linename,a.lineicon,a.seotitle,a.sellpoint,a.linepic,a.storeprice,a.lineprice,a.linedate,a.features,a.transport,a.lineday,a.startcity,a.overcity,a.shownum,a.satisfyscore,a.bookcount,a.jifentprice,a.jifenbook,a.jifencomment,a.attrid,a.kindlist,a.color,a.iconlist";

	    //通过属性调用
		if($flag=='byattr')
		{
           $attrid=$refObj->Fields['attrid'];
		   $sql="select {$basefield} from #@__line as a left join #@__allorderlist b on (a.id=b.aid and b.typeid=1) where a.ishidden=0 and FIND_IN_SET($attrid,a.attrid) order by b.displayorder asc,a.modtime desc,a.addtime desc limit {$limit},{$row}";

		}

    if($type=='mdd') //指定目的地时关联文章调用.
    {
        echo 'here';
        if($flag=='hot')
        {
            $orderby='order by case when c.displayorder is null then 9999 end,c.displayorder asc,a.modtime desc,a.addtime desc';
        }
        else if($flag=='recommend')
        {
            $orderby='order by case when c.displayorder is null then 9999 end,c.displayorder asc,a.modtime desc,a.addtime desc';
        }
        else if($flag=='specical')
        {
            $orderby='order by case when c.displayorder is null then 9999 end,c.displayorder asc,a.modtime desc,a.addtime desc ';
        }
        else
        {
            $orderby='order by case when c.displayorder is null then 9999 end,c.displayorder asc,a.modtime desc,a.addtime desc';
        }
        $sonid=isset($definekind) ? $definekind : $refObj->Fields['kindid'];
        $shownum=isset($row) ? $row : $refObj->Fields['shownum'];
        $shownum = empty($shownum) ? 6 : $shownum;


        if(isset($sonid))
        {

            $number=isset($refObj->Fields['shownumber']) ? $refObj->Fields['shownumber'] : $row;//如果模块设置了显示数量则使用.
            $sql="select {$basefield},c.isjian,c.istejia,c.isding  from #@__line as a left join #@__kindorderlist as c on (c.classid=$sonid and a.id=c.aid  and c.typeid=1) where a.ishidden=0 and  FIND_IN_SET($sonid,a.kindlist) {$orderby}  limit {$limit},{$shownum}";
            echo $sql."</br>";



        }

        else return '';
    }


    $dsql->SetQuery($sql);
    $dsql->Execute();
    $ctp = new STTagParse();
    $ctp->SetNameSpace("field","[","]");
    $ctp->LoadSource($innertext);
    $GLOBALS['autoindex'] = 0;
	$num=0;
    while($row = $dsql->GetArray())
    {
        $GLOBALS['autoindex']++;
		$webroot=GetWebURLByWebid($row['webid']);
		$url= $webroot . "/lines/show_{$row['aid']}.html";;
		$row['url']= $url;
		$row['bookurl']= "{$webroot}/lines/booking_{$row['aid']}.html";
        $startcity = getStartCityName($row['startcity']);
        $startcity = !empty($startcity) ? "[{$startcity}出发]" : '';

		$row['title']="{$startcity}{$row['linename']}";
        $row['color'] = !empty($row['color']) ? "color:{$row['color']}" : '';
		$real=getLineRealPrice($row['aid'],$row['webid']);
		$row['lineprice']=$real ? $real : $row['lineprice'];
		
		$row['commentnum']=Helper_Archive::getCommentNum($row['id'],1); //评论次数
		$row['sellnum']=Helper_Archive::getSellNum($row['id'],1)+$row['bookcount']; //销售数量
		$row['satisfyscore']=Helper_Archive::getSatisfyScore($row['id'],1); //满意度
		
		if(!empty($row['lineprice'])&&!empty($row['storeprice']))
		   $row['discount']=abs((int)$row['storeprice']-(int)$row['lineprice']);
		 else
		   $row['discount']=0;

        $row['destname']=Helper_Archive::getBelongDestName($row['kindlist']);//所属目的地
        $row['destid']=array_remove_value($row['kindlist']);
        $row['pinyin']=Helper_Archive::getDestPinyin($row['destid']);

		$row['price'] = empty($row['lineprice'])?'<span class="rmb_1">电询</span>':"<span class='rmb_1'>&yen;</span><span class='rmb_2'>".$row['lineprice'].'</span>';
        $row['price2'] = empty($row['lineprice'])?'<span>电询</span>' : '<span>&yen;</span><strong>'.$row['lineprice'].'</strong><i>起</i>';
        $row['agentprice'] = $row['storeprice'];
		$row['sellprice'] = empty($row['lineprice'])?'0':$row['lineprice']; //没有HTML标识的价格
		$row['storeprice']=!empty($row['storeprice'])?"<span class=\"rmb_2\">&yen;</span>".$row['storeprice']:"<span class=\"rmb_1\">电询</span>";
		$row['lineseries']=getSeries($row['id'],'01');

		$row['litpic']=getUploadFileUrl($row['linepic']);
		$row['lit240']=getUploadFileUrl(str_replace('litimg','lit240',$row['linepic']));
		$row['lit160']=getUploadFileUrl(str_replace('litimg','lit160',$row['linepic']));
        $row['jifentprice'] = MyLine::getMinTprice($row['id']);


		$row['list']=$num;

		
        foreach($ctp->CTags as $tagid=>$ctag)
        {
                if($ctag->GetName()=='array')
                {
                        $ctp->Assign($tagid, $row);
                }
                else
                {
                   $ctp->Assign($tagid,$row[$ctag->GetName()]); 
                }
        }
        $revalue .= $ctp->GetResult();
		
    }
    return $revalue;
}

class MyLine {

    public static function getMinTprice($lineid)
    {
        global $dsql;
        $sql = "select min(jifentprice) as price from sline_line_suit where lineid='$lineid'";
        $row = $dsql->GetOne($sql);
        return $row['price'] ? $row['price'] : 0 ;

    }


}

