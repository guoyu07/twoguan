<?php   if(!defined('SLINEINC')) exit('Request Error!');
/**
 * 属性分类调用标签
 *
 * @version        $Id: grouplist.lib.php netman
 * @package        Stourweb.Taglib
 * @copyright      Copyright (c) 2007 - 2013, Stourweb, Inc.
 * @link           http://www.stourweb.com
 */

require_once(SLINEINC.'/view.class.php');

function lib_grouplist(&$ctag,&$refObj)
{

    global $dsql;

    include(SLINEDATA."/webinfo.php");

    $attlist="row|8,flag|,groupid|1,filterid|";

    FillAttsDefault($ctag->CAttribute->Items,$attlist);

    extract($ctag->CAttribute->Items, EXTR_SKIP);

    $innertext = trim($ctag->GetInnerText());

    $artlist = '';

	$tablearr=array('1'=>'#@__line_attr','2'=>'#@__hotel_attr','3'=>'#@__car_attr','4'=>'#@__article_attr','5'=>'#@__spot_attr','6'=>'#@__photo_attr','13'=>'#@__tuan_attr');
    $typeid = 1;
    //$tablename=$tablearr[1];
    $tablename = '#@__line_attr';

   
    if($innertext=='') return '';

   

    //获得类别ID总数的信息

    $groupids = array();

	$groupnames=array();
	
	$w = !empty($filterid) ? " and id not in($filterid)" : '';//排除不要的项

	$sql="select id,attrname from {$tablename} where webid=0 and pid='$groupid' and isopen=1 order by displayorder asc limit 0,$row" ;
	

    $dsql->SetQuery($sql);

    $dsql->Execute();

    while($row = $dsql->GetArray()) 
	{


	     $attrids[] = $row['id'];

		 $attrnames[]=$row['attrname'];//属性名


    }



    if(!isset($attrids[0])) return ''; //如里不存在则退出

    $GLOBALS['itemindex']=0;

    for($i=0;isset($attrids[$i]);$i++)
    {

        $GLOBALS['itemindex']++;
        $pv = new View(0);
		$pv->Fields['attrname']=$attrnames[$i];
		$pv->Fields['attrid']=$attrids[$i];
		$pv->Fields['typeid']=$typeid;
        $tagdir = dirname(__FILE__);
        $pv->SetTemplet($innertext,'string',$tagdir);

        $artlist .= $pv->GetResult();

    }
    return $artlist;

}






 ?>