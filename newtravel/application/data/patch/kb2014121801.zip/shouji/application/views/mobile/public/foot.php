 <div class="footer">
  	<div class="back_top" href="javascript:void();" onclick="scroll(0,0);">返回顶部</div>
    <div class="terminal">
    	<a href="{$cmsurl}">手机版</a>
 |
 <a href="{$computerurl}/?computerversion=1">电脑板</a>
 |
 <a href="{$cmsurl}corp/">关于我们</a>
 </div>
 </div>
{php echo Common::getSysPara('cfg_tongjicode'); }