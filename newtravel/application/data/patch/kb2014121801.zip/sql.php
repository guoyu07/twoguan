<?php
require_once(dirname(__FILE__) . "/include/common.inc.php");
require_once(dirname(__FILE__)."/stourtravel/inc/inc_file.php");

$dsql->safeCheck = false; //关闭安全检查

addInfo();



//增加伪静态规则
function addHtaccess()
{
    $ifile = new iFile('.htaccess','r');
    $content=$ifile->readcontent();//获取文件内容
    $ifile->closefile();//文件关闭
    $ifiles = new iFile('./.htaccess','w');
    $new = "RewriteRule ^lines/([a-z0-9]+)-0-0-([0-9]+)-([0-9]+)-([0-9]+)-([^-]+)-([0-9]+)-([0-9_]+)?$ lines/search.php?dest_id=$1&day=$2&priceid=$3&sorttype=$4&keyword=$5&startcity=$6&attrid=$7

RewriteRule ^lines/([a-z0-9]+)-0-0-([0-9]+)-([0-9]+)-([0-9]+)-([^-]+)-([0-9]+)-([0-9_]+)-([0-9]+)?$ lines/search.php?dest_id=$1&day=$2&priceid=$3&sorttype=$4&keyword=$5&startcity=$6&attrid=$7&pageno=$8";
    $ifiles->writefile($content . "\r\n" . $new);

}

function addInfo()
{
	global $dsql;
	$sql="insert into sline_sysconfig(webid,varname,info,value) values ('0','cfg_supplier_msg','供应商通知','客户{#LINKMAN#}预订{#PRODUCTNAME#}产品,联系电话:{#PHONE#},人数:{#NUMBER#},单价:{#PRICE#},总价:{#TOTALPRICE#},请尽快处理.')";
    $dsql->ExecuteNoneQuery($sql);

}



