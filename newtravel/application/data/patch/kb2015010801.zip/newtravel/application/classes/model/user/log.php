<?php defined('SYSPATH') or die('No direct access allowed.');

class Model_User_Log extends ORM {

    protected  $_table_name = 'user_log';

}