<?php defined('SYSPATH') or die('No direct access allowed.');

class Model_Car_Extend_Field extends ORM {

}