<?php
require_once(dirname(__FILE__) . "/include/common.inc.php");
require_once(dirname(__FILE__)."/include/file.class.php");

$dsql->safeCheck = false; //关闭安全检查
addTable();
//updateLinePrice();
//modifyHtaccess();

/*function sqlModify()
{
    global $dsql;
    $sql1 = "INSERT INTO `sline_advertise_type` VALUES (45,'0','手机首页轮播广告','MobileIndexRollAd',320,200,1,0,1416981629);";
    $dsql->ExecuteNoneQuery($sql1);
}*/

//增加伪静态规则
/*function modifyHtaccess()
{
    $ifile = new STFile('.htaccess','r');
    $content=$ifile->readcontent();//获取文件内容
    $ifile->closefile();//文件关闭
    $ifiles = new STFile('./.htaccess','w');
    $replace = array();
    $replace[]="RewriteRule ^tuan/([a-z0-9]+)-([0-9_]+)$ tuan/index.php?dest_id=$1&attrid=$2";
    $replace[]="RewriteRule ^tuan/([a-z0-9]+)-([0-9_]+)-([0-9]+)$ tuan/index.php?dest_id=$1&attrid=$2&pageno=$3";
    $replace[]="RewriteRule ^tuan/([a-z0-9]+)(/)?$ tuan/index.php?dest_id=$1";
    $new = array();
    $new[] = "RewriteRule ^tuan/([a-z0-9]+)-([0-9]+)-([0-9_]+)$ tuan/index.php?dest_id=$1&status=$2&attrid=$3";
    $new[] = "RewriteRule ^tuan/([a-z0-9]+)-([0-9]+)-([0-9_]+)-([0-9]+)$ tuan/index.php?dest_id=$1&status=$2&attrid=$3&pageno=$4";
    $new[] = "RewriteRule ^tuan/([a-z0-9]+)(/)?$ tuan/index.php?dest_id=$1";
    $content = str_replace($replace,$new,$content);
    $ifiles->writefile($content);

}*/

function addTable()
{
    global $dsql;
    $sqllist="

ALTER TABLE `sline_line_content`
	ADD COLUMN `ismaintable` INT(1) UNSIGNED NULL DEFAULT '0' COMMENT '是否主表' AFTER `isline`;
alter table sline_advertise modify column normalbody text default null;
insert into sline_module_config(aid,webid,pagename,shortname,typeid) values('32','0','机票首页','index',9);
insert into sline_nav(webid,typeid,pid,typename,shortname,url,linktype,linktitle) values('0','9','0','机票','机票','/ticket/','1','机票');
CREATE TABLE `sline_line_extend_field` (
	`id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '自增id',
	`productid` INT(11) NULL DEFAULT NULL COMMENT '产品id',
	PRIMARY KEY (`id`),
	INDEX `id` (`id`)
)
COMMENT='线路字段扩展表'
COLLATE='utf8_general_ci'
ENGINE=myisam;

CREATE TABLE `sline_hotel_extend_field` (
	`id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '自增id',
	`productid` INT(11) NULL DEFAULT NULL COMMENT '产品id',
	PRIMARY KEY (`id`),
	INDEX `id` (`id`)
)
COMMENT='酒店字段扩展表'
COLLATE='utf8_general_ci'
ENGINE=myisam;

CREATE TABLE `sline_car_extend_field` (
	`id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '自增id',
	`productid` INT(11) NULL DEFAULT NULL COMMENT '产品id',
	PRIMARY KEY (`id`),
	INDEX `id` (`id`)
)
COMMENT='租车字段扩展表'
COLLATE='utf8_general_ci'
ENGINE=myisam;

CREATE TABLE `sline_spot_extend_field` (
	`id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '自增id',
	`productid` INT(11) NULL DEFAULT NULL COMMENT '产品id',
	PRIMARY KEY (`id`),
	INDEX `id` (`id`)
)
COMMENT='景点字段扩展表'
COLLATE='utf8_general_ci'
ENGINE=myisam;

CREATE TABLE `sline_photo_extend_field` (
	`id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '自增id',
	`productid` INT(11) NULL DEFAULT NULL COMMENT '产品id',
	PRIMARY KEY (`id`),
	INDEX `id` (`id`)
)
COMMENT='相册字段扩展表'
COLLATE='utf8_general_ci'
ENGINE=myisam;

CREATE TABLE `sline_article_extend_field` (
	`id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '自增id',
	`productid` INT(11) NULL DEFAULT NULL COMMENT '产品id',
	PRIMARY KEY (`id`),
	INDEX `id` (`id`)
)
COMMENT='文章字段扩展表'
COLLATE='utf8_general_ci'
ENGINE=myisam;

CREATE TABLE `sline_visa_extend_field` (
	`id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '自增id',
	`productid` INT(11) NULL DEFAULT NULL COMMENT '产品id',
	PRIMARY KEY (`id`),
	INDEX `id` (`id`)
)
COMMENT='签证字段扩展表'
COLLATE='utf8_general_ci'
ENGINE=myisam;


CREATE TABLE `sline_tuan_extend_field` (
	`id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '自增id',
	`productid` INT(11) NULL DEFAULT NULL COMMENT '产品id',
	PRIMARY KEY (`id`),
	INDEX `id` (`id`)
)
COMMENT='团购字段扩展表'
COLLATE='utf8_general_ci'
ENGINE=myisam;

ALTER TABLE `sline_line_suit_price`
	ADD COLUMN `description` VARCHAR(50) NULL DEFAULT NULL COMMENT '描述' AFTER `adultprice`,
	ADD COLUMN `number` INT(11) NULL DEFAULT NULL COMMENT '库存' AFTER `description`;
ALTER TABLE `sline_hotel_room_price`
	ADD COLUMN `number` INT(11) NULL COMMENT '库存' AFTER `description`;
ALTER TABLE `sline_car_suit_price`
    ADD COLUMN `description` VARCHAR(50) NULL DEFAULT NULL COMMENT '描述'
	ADD COLUMN `number` INT(11) NULL COMMENT '库存' ;
ALTER TABLE `sline_visa`
	ADD COLUMN `number` INT(11) NULL DEFAULT NULL COMMENT '库存';

";
    $sqlArr = explode(';',$sqllist);

    foreach($sqlArr as $sql)
    {
        $dsql->ExecuteNoneQuery($sql);
    }





}












