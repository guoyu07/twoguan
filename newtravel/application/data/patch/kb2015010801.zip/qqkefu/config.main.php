<?php 
$pos="left";
$posh="0px";
$post="10%";
$display=1;
$qqcl="3";$phonenum="028-88585858";