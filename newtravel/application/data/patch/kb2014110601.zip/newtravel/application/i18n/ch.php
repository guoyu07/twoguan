<?php defined('SYSPATH') or die('No direct script access.');

return array(

    'First'=>'首页',
    'Previous'=>'上一页',
    'Next'=>'下一页',
    'Last'=>'末页',
    'norightmsg'=>'你没有权限进行此项操作，请联系管理员！',
    'onlysys'=>'只有系统管理员能进行权限设置,请联系管理员!'
);