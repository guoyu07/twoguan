<?php
require_once(dirname(__FILE__) . "/include/common.inc.php");

$dsql->safeCheck = false; //关闭安全检查
sqlModify();

function sqlModify()
{
    global $dsql;
	
    $sql1="alter table sline_hotel_room_price drop primary key ;";
    $sql2="alter table sline_car_attr add column description varchar(255);";
 
    $dsql->ExecuteNoneQuery($sql1);
    $dsql->ExecuteNoneQuery($sql2);
   

}









