<?php defined('SYSPATH') or die('No direct script access.');
class Controller_Test extends Stourweb_Controller{

    public function action_sql()
    {
        $query = '';
        $sqlfile=BASEPATH.'/sql.txt';
        if(file_exists($sqlfile))//如果存在升级文件
        {

            $fp = fopen($sqlfile,'r');
            while(!feof($fp))
            {
                $line = rtrim(fgets($fp, 1024));

                if(preg_match("#;$#", $line))
                {

                    $query .= $line;

                    DB::query(null,$query)->execute();

                    $query='';
                }
                else if(!preg_match("#^(\/\/|--)#", $line))
                {
                    $query .= $line;
                }
            }
            fclose($fp);
            //@unlink($sqlfile);//删除升级sql文件
        }
        echo 'execute ok!';
    }
}