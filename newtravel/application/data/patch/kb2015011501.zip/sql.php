<?php
require_once(dirname(__FILE__) . "/include/common.inc.php");
require_once(dirname(__FILE__)."/include/file.class.php");

$dsql->safeCheck = false; //关闭安全检查
addTable();
//updateLinePrice();
//modifyHtaccess();

/*function sqlModify()
{
    global $dsql;
    $sql1 = "INSERT INTO `sline_advertise_type` VALUES (45,'0','手机首页轮播广告','MobileIndexRollAd',320,200,1,0,1416981629);";
    $dsql->ExecuteNoneQuery($sql1);
}*/

//增加伪静态规则
/*function modifyHtaccess()
{
    $ifile = new STFile('.htaccess','r');
    $content=$ifile->readcontent();//获取文件内容
    $ifile->closefile();//文件关闭
    $ifiles = new STFile('./.htaccess','w');
    $replace = array();
    $replace[]="RewriteRule ^tuan/([a-z0-9]+)-([0-9_]+)$ tuan/index.php?dest_id=$1&attrid=$2";
    $replace[]="RewriteRule ^tuan/([a-z0-9]+)-([0-9_]+)-([0-9]+)$ tuan/index.php?dest_id=$1&attrid=$2&pageno=$3";
    $replace[]="RewriteRule ^tuan/([a-z0-9]+)(/)?$ tuan/index.php?dest_id=$1";
    $new = array();
    $new[] = "RewriteRule ^tuan/([a-z0-9]+)-([0-9]+)-([0-9_]+)$ tuan/index.php?dest_id=$1&status=$2&attrid=$3";
    $new[] = "RewriteRule ^tuan/([a-z0-9]+)-([0-9]+)-([0-9_]+)-([0-9]+)$ tuan/index.php?dest_id=$1&status=$2&attrid=$3&pageno=$4";
    $new[] = "RewriteRule ^tuan/([a-z0-9]+)(/)?$ tuan/index.php?dest_id=$1";
    $content = str_replace($replace,$new,$content);
    $ifiles->writefile($content);

}*/

function addTable()
{
    global $dsql;
    $sqllist="alter table sline_line_suit_price modify column number int(10) default -1;
alter table sline_hotel_room_price modify column number int(10) default -1;
alter table sline_car_suit_price modify column number int(10) default -1;
alter table sline_visa modify column number int(10) default -1;
alter table sline_ticket modify column number int(10) default -1;
alter table sline_tuan modify column totalnum int(10) default -1;
update sline_line_suit_price set number=-1;
update sline_hotel_room_price set number=-1;
update sline_car_suit_price set number=-1;
update sline_spot_ticket set number=-1;
alter table sline_visa modify column number int(10) default -1;
update sline_visa set number=-1;
update sline_tuan set totalnum=-1;
INSERT INTO `sline_advertise_type` ( `webid`, `position`, `tagname`, `width`, `height`, `type`, `issystem`, `addtime`) VALUES ( '0', '首页顶部广告1', 'IndexAd1', 368, 228, 1, 0, 1421112936);
INSERT INTO `sline_advertise_type` ( `webid`, `position`, `tagname`, `width`, `height`, `type`, `issystem`, `addtime`) VALUES ( '0', '首页顶部广告2', 'IndexAd2', 183, 150, 1, 0, 1421113023);
INSERT INTO `sline_advertise_type` ( `webid`, `position`, `tagname`, `width`, `height`, `type`, `issystem`, `addtime`) VALUES ( '0', '首页顶部广告3', 'IndexAd3', 183, 150, 1, 0, 1421112976);
INSERT INTO `sline_page` (`id`, `pid`, `kindname`, `pagename`) VALUES (54, '1', '底部FAQ栏', 'help');
INSERT INTO `sline_page` (`id`, `pid`, `kindname`, `pagename`) VALUES (55, '1', '底部友情连接', 'flink');
ALTER TABLE `sline_member`
	ADD UNIQUE INDEX `mobile` (`mobile`, `email`);
";
    $sqlArr = explode(';',$sqllist);

    foreach($sqlArr as $sql)
    {
        $dsql->ExecuteNoneQuery($sql);
    }





}












