<?php
require_once(dirname(__FILE__)."/../include/common.inc.php");
require_once SLINEINC."/view.class.php";

$pv = new View($typeid);

$pv->SetTemplet(SLINETEMPLATE ."/".$cfg_df_style ."/" ."customize/" ."index.htm");

$pv->Display();

exit();
?>