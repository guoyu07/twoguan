<?php
require_once(dirname(__FILE__) . "/include/common.inc.php");
//require_once(dirname(__FILE__)."/include/file.class.php");

$dsql->safeCheck = false; //关闭安全检查
addTable();

//updateLinePrice();
//modifyHtaccess();



function addTable()
{
    global $dsql;
    $sql1="INSERT INTO `sline_advertise` ( `webid`, `typeid`, `tagname`, `adposition`, `normalbody`, `expirebody`, `starttime`, `endtime`, `addtime`, `modtime`, `picurl`, `linkurl`, `adtype`, `litpic`, `linktext`, `displayorder`, `kindlist`) VALUES ( 0, 0, 'IndexAd3', '首页顶部广告3', '<a href=\"\" style=\"margin-bottom:10px\" class=\"fl clearfix\"><img src=\"/uploads/main/allimg/20150116/20150116112314.jpg\" alt=\"#\" width=\"183\" height=\"150\" /></a>', NULL, NULL, NULL, 1421378597, NULL, '/uploads/main/allimg/20150116/20150116112314.jpg', '', 1, NULL, '#', NULL, NULL);";
   $sql2="INSERT INTO `sline_advertise` ( `webid`, `typeid`, `tagname`, `adposition`, `normalbody`, `expirebody`, `starttime`, `endtime`, `addtime`, `modtime`, `picurl`, `linkurl`, `adtype`, `litpic`, `linktext`, `displayorder`, `kindlist`) VALUES ( 0, 0, 'IndexAd2', '首页顶部广告2', '<a href=\"\" style=\"margin-bottom:10px\" class=\"fl clearfix\"><img src=\"/uploads/main/allimg/20150116/20150116112258.jpg\" alt=\"#\" width=\"183\" height=\"150\" /></a>', NULL, NULL, NULL, 1421378582, NULL, '/uploads/main/allimg/20150116/20150116112258.jpg', '#', 1, NULL, '#', NULL, NULL);";
   $sql3="INSERT INTO `sline_advertise` ( `webid`, `typeid`, `tagname`, `adposition`, `normalbody`, `expirebody`, `starttime`, `endtime`, `addtime`, `modtime`, `picurl`, `linkurl`, `adtype`, `litpic`, `linktext`, `displayorder`, `kindlist`) VALUES ( 0, 0, 'IndexAd1', '首页顶部广告1', '<a href=\"\" style=\"margin-bottom:10px\" class=\"fl clearfix\"><img src=\"/uploads/main/allimg/20150116/20150116112242.jpg\" alt=\"#\" width=\"368\" height=\"228\" /></a>', NULL, NULL, NULL, 1421378566, NULL, '/uploads/main/allimg/20150116/20150116112242.jpg', '#', 1, NULL, '#', NULL, NULL);";
   /* $sqlArr = explode(';',$sqllist);

    foreach($sqlArr as $sql)
    {
        //echo $sql."\r\n";
      $dsql->ExecuteNoneQuery($sql);
       echo $dsql->GetError();
    }*/

    if(!checkAdE('IndexAd3'))
    {
        $dsql->ExecuteNoneQuery($sql1);
    }
    if(!checkAdE('IndexAd2'))
    {
        $dsql->ExecuteNoneQuery($sql2);
    }
    if(!checkAdE('IndexAd1'))
    {
        $dsql->ExecuteNoneQuery($sql3);
    }




}
function checkAdE($tagname)
{
    global $dsql;
    $sql = "select count(*) as num from sline_advertise where tagname='$tagname' ";
    $row = $dsql->GetOne($sql);
    return $row['num'] ? $row['num'] : 0;
}












