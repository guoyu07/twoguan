 <div class="footer">
  	<div class="back_top" href="javascript:void();" onclick="scroll(0,0);">返回顶部</div>
    <div class="terminal">
    	<a href="{$cmsurl}">手机版</a>
 |
 <a href="{$computerurl}">电脑板</a>
 </div>
 </div>
 div:{php echo Common::getSysPara('cfg_tongjicode'); }