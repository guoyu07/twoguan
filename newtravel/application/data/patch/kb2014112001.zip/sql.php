<?php
require_once(dirname(__FILE__) . "/include/common.inc.php");

$dsql->safeCheck = false; //关闭安全检查
sqlModify();
updateLinePrice();

function sqlModify()
{
    global $dsql;
    $sql1 = "CREATE TABLE IF NOT EXISTS `sline_member_jifen_log` (
  `id` int(11) NOT NULL auto_increment,
  `memberid` int(11) default NULL,
  `content` text COMMENT '积分描述',
  `addtime` int(10) unsigned default NULL COMMENT '添加时间',
  `type` int(1) unsigned default NULL COMMENT '消息类型,1,使用,2,获取',
  `jifen` int(11) unsigned default NULL COMMENT '本次操作的积分数',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员积分使用记录表';";
	
    $sql2="alter table sline_member_order add column usejifen int(11);";
    $sql3="alter table sline_member_order add column needjifen int(11);";

  
 
    $dsql->ExecuteNoneQuery($sql1);
    $dsql->ExecuteNoneQuery($sql2);
    $dsql->ExecuteNoneQuery($sql3);
  
   

}

function updateLinePrice()
{
   global $dsql;
   $sql = "select id from sline_line where ishidden=0";
   $arr = $dsql->getAll($sql);
   foreach($arr as $row)
   {
       $lineid = $row['id'];
       $sql = "SELECT MIN(adultprice) as price FROM sline_line_suit_price WHERE lineid='$lineid' and adultprice>0";
       $ar = $dsql->GetOne($sql);
       $price = $ar['price'] ? $ar['price'] : 0;
       if($price!=0)
       {
           $sql = "update sline_line set lineprice='$price' where id='$lineid'";
           $dsql->ExecuteNoneQuery($sql);
       }

   }
}










