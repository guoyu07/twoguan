<?php
require_once(dirname(__FILE__) . "/include/common.inc.php");
//require_once(dirname(__FILE__)."/include/file.class.php");

$dsql->safeCheck = false; //关闭安全检查
addTable();



function addTable()
{
    global $dsql;
    $sql1 = "alter table sline_hotel_rank alter column webid set default '1';";
    $sql2 = "ALTER TABLE `sline_plugin_leftnav` ADD COLUMN `litpic` VARCHAR(200) NULL DEFAULT NULL COMMENT '图标'";
	$sql3 = "ALTER TABLE `sline_plugin_leftnav` ADD COLUMN `remark` VARCHAR(200) NULL DEFAULT NULL COMMENT '自定义说明'";
    $sql4 = "ALTER TABLE `sline_article` ADD COLUMN `summary` VARCHAR(255) NULL DEFAULT NULL COMMENT '摘要'";
    

	$dsql->ExecuteNoneQuery($sql1);

    if(!checkColumn('sline_plugin_leftnav','litpic'))
    {
        $dsql->ExecuteNoneQuery($sql2);
    }
    if(!checkColumn('sline_plugin_leftnav','remark'))
    {
        $dsql->ExecuteNoneQuery($sql3);
    }
	 if(!checkColumn('sline_article','summary'))
    {
        $dsql->ExecuteNoneQuery($sql4);
    }
  






}
function checkColumn($table,$column)
{
    global $dsql;
    $sql = "show columns from `{$table}` like '$column'";
    $row = $dsql->GetOne($sql);
    return isset($row['Field']) ? 1 : 0;
}

function checkTable($table)
{
    global $dsql;
    $sql = "SHOW TABLES LIKE '$table'";
    $row = $dsql->getAll($sql);
    return count($row) ? 1 : 0;

}












