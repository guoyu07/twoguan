<?php
require_once(dirname(__FILE__) . "/include/common.inc.php");
require_once(dirname(__FILE__)."/include/file.class.php");

$dsql->safeCheck = false; //关闭安全检查
addTable();



function addTable()
{
    global $dsql;
 

	$sql1="ALTER TABLE `sline_article` ADD COLUMN `piclist` TEXT NULL DEFAULT NULL COMMENT '图片列表'";
    $sql2="ALTER TABLE `sline_article` ADD COLUMN `attachment` VARCHAR(255) NULL COMMENT '附件'";
    $sql3="ALTER TABLE `sline_article` ADD COLUMN `downnum` INT(10) UNSIGNED NULL DEFAULT '10' COMMENT '下载次数'";


    if(!checkColumn('sline_article','piclist'))
    {
        $dsql->ExecuteNoneQuery($sql1);
    }
	 if(!checkColumn('sline_article','attachment'))
    {
        $dsql->ExecuteNoneQuery($sql2);
    }
	 if(!checkColumn('sline_article','downnum'))
    {
        $dsql->ExecuteNoneQuery($sql3);
    }





    /*if(!checkColumn('sline_plugin_leftnav','litpic'))
    {
        $dsql->ExecuteNoneQuery($sql2);
    }
    if(!checkColumn('sline_plugin_leftnav','remark'))
    {
        $dsql->ExecuteNoneQuery($sql3);
    }
	 if(!checkColumn('sline_article','summary'))
    {
        $dsql->ExecuteNoneQuery($sql4);
    } */



	






}
//增加伪静态规则
function modifyHtaccess()
{
    $ifile = new STFile('.htaccess','r');
    $content=$ifile->readcontent();//获取文件内容
    $ifile->closefile();//文件关闭
    $ifiles = new STFile('./.htaccess','w');
    $replace = array();
    $replace[]="RewriteCond $1 !^(stourtravel|visa|cars|lines|spots|raiders|servers|uploads|photos|hotels|questions|destination|min|sline|member|tuan|customize|install|zhuanti|ticket)";
   // $replace[]="RewriteRule ^tuan/([a-z0-9]+)-([0-9_]+)-([0-9]+)$ tuan/index.php?dest_id=$1&attrid=$2&pageno=$3";
   // $replace[]="RewriteRule ^tuan/([a-z0-9]+)(/)?$ tuan/index.php?dest_id=$1";
    $new = array();
    $new[] = "RewriteCond %{REQUEST_FILENAME} !-d";
    //$new[] = "RewriteRule ^tuan/([a-z0-9]+)-([0-9]+)-([0-9_]+)-([0-9]+)$ tuan/index.php?dest_id=$1&status=$2&attrid=$3&pageno=$4";
   // $new[] = "RewriteRule ^tuan/([a-z0-9]+)(/)?$ tuan/index.php?dest_id=$1";
    $content = str_replace($replace,$new,$content);
    $ifiles->writefile($content);

}



function checkColumn($table,$column)
{
    global $dsql;
    $sql = "show columns from `{$table}` like '$column'";
    $row = $dsql->GetOne($sql);
    return isset($row['Field']) ? 1 : 0;
}

function checkTable($table)
{
    global $dsql;
    $sql = "SHOW TABLES LIKE '$table'";
    $row = $dsql->getAll($sql);
    return count($row) ? 1 : 0;

}












