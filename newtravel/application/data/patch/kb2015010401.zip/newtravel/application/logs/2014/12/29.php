<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2014-12-29 11:07:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-29 11:07:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-29 14:18:17 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-29 14:18:17 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-29 14:24:00 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:00 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:00 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:00 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:00 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:00 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:00 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:00 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:00 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:00 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:00 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:00 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:00 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:00 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:00 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:00 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:00 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:00 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:00 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:00 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:01 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:01 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:02 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:02 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:03 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:03 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:03 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:03 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:03 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:03 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:03 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:03 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:03 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:03 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:03 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:03 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:03 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:03 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:03 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:03 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:03 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:03 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:03 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:03 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:03 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:03 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:04 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:04 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:04 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:04 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:04 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:04 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:04 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:04 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:04 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:04 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:04 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:04 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:04 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:04 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:04 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:04 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:04 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:04 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:04 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:04 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:04 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:04 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:04 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:04 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:04 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:04 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:42 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:42 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:43 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:43 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:43 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:43 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 14:24:43 --- ERROR: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
2014-12-29 14:24:43 --- STRACE: Kohana_Exception [ 0 ]: Cannot update module_config model because it is not loaded. ~ MODPATH\orm\classes\kohana\orm.php [ 1449 ]
--
#0 D:\web\standsmore\newtravel\application\classes\controller\module.php(226): Kohana_ORM->update()
#1 [internal function]: Controller_Module->action_ajax_updatesort()
#2 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_Module))
#3 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#5 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#6 {main}
2014-12-29 15:08:40 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL lines was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-29 15:08:40 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL lines was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-29 16:48:44 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-29 16:48:44 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}