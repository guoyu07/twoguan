<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2014-12-26 10:02:11 --- ERROR: SoapFault [ 0 ]: SOAP-ERROR: Parsing WSDL: Couldn't load from 'http://update.souxw.com/service/api.asmx?WSDL' : failed to load external entity "http://update.souxw.com/service/api.asmx?WSDL"
 ~ APPPATH\classes\model\upgrade.php [ 22 ]
2014-12-26 10:02:11 --- STRACE: SoapFault [ 0 ]: SOAP-ERROR: Parsing WSDL: Couldn't load from 'http://update.souxw.com/service/api.asmx?WSDL' : failed to load external entity "http://update.souxw.com/service/api.asmx?WSDL"
 ~ APPPATH\classes\model\upgrade.php [ 22 ]
--
#0 D:\web\standsmore\newtravel\application\classes\model\upgrade.php(22): SoapClient->SoapClient('http://update.s...')
#1 D:\web\standsmore\newtravel\application\classes\model\upgrade.php(70): Model_Upgrade->getRelease('lastnew')
#2 D:\web\standsmore\newtravel\application\classes\controller\app.php(53): Model_Upgrade->getNewVInfo()
#3 [internal function]: Controller_App->action_ajax_check_update()
#4 D:\web\standsmore\newtravel\system\classes\kohana\request\client\internal.php(116): ReflectionMethod->invoke(Object(Controller_App))
#5 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#7 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#8 {main}
2014-12-26 10:02:11 --- ERROR: ErrorException [ 1 ]: SOAP-ERROR: Parsing WSDL: Couldn't load from 'http://update.souxw.com/service/api.asmx?WSDL' : failed to load external entity "http://update.souxw.com/service/api.asmx?WSDL"
 ~ APPPATH\classes\model\upgrade.php [ 22 ]
2014-12-26 10:02:11 --- STRACE: ErrorException [ 1 ]: SOAP-ERROR: Parsing WSDL: Couldn't load from 'http://update.souxw.com/service/api.asmx?WSDL' : failed to load external entity "http://update.souxw.com/service/api.asmx?WSDL"
 ~ APPPATH\classes\model\upgrade.php [ 22 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2014-12-26 10:02:21 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-26 10:02:21 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-26 14:02:43 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-26 14:02:43 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-26 18:29:20 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-26 18:29:20 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}