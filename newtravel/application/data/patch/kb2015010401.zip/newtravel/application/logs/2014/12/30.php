<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2014-12-30 09:30:36 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 09:30:36 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 09:31:35 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/data/TreeStore.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 09:31:35 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/data/TreeStore.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 09:34:39 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 09:34:39 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 09:35:38 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 09:35:38 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 09:35:59 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 09:35:59 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 09:37:37 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 09:37:37 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 09:38:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 09:38:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 09:38:45 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 09:38:45 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 09:41:06 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 09:41:06 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 09:47:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 09:47:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 09:47:10 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 09:47:10 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 09:47:41 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 09:47:41 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 09:47:43 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 09:47:43 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 09:47:46 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 09:47:46 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 09:47:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 09:47:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 09:47:59 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 09:47:59 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 10:15:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 10:15:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/js/extjs/src/container/Viewport.js was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 10:16:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 10:16:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 10:20:41 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 10:20:41 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 10:21:17 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 10:21:17 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 11:41:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 11:41:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 13:10:57 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 13:10:57 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 13:45:08 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 13:45:08 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}
2014-12-30 15:29:01 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
2014-12-30 15:29:01 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL public/images/ico-bg.png was not found on this server. ~ SYSPATH\classes\kohana\request\client\internal.php [ 87 ]
--
#0 D:\web\standsmore\newtravel\system\classes\kohana\request\client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 D:\web\standsmore\newtravel\system\classes\kohana\request.php(1160): Kohana_Request_Client->execute(Object(Request))
#2 D:\web\standsmore\newtravel\index.php(121): Kohana_Request->execute()
#3 {main}