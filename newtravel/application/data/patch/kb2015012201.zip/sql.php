<?php
require_once(dirname(__FILE__) . "/include/common.inc.php");
//require_once(dirname(__FILE__)."/include/file.class.php");

$dsql->safeCheck = false; //关闭安全检查
addTable();

//updateLinePrice();
//modifyHtaccess();



function addTable()
{
    global $dsql;


    $sql1 = "ALTER TABLE `sline_member_order` ADD COLUMN `remark` MEDIUMTEXT NULL DEFAULT NULL COMMENT '订单备注'";
    $sql2 = "ALTER TABLE `sline_member_order` ADD COLUMN `pid` INT NULL DEFAULT '0' COMMENT '父级订单id'";
    $sql3 = "ALTER TABLE `sline_hotel_room` change COLUMN `roomnum` `number` int(11) DEFAULT '0'";
    $sql4 = "ALTER TABLE `sline_hotel_room_price` ADD COLUMN `number` INT NULL DEFAULT '-1' COMMENT '库存'";

    $sql5 = "CREATE TABLE `sline_member_order_tourer` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`tourername` VARCHAR(255) NULL DEFAULT '0' COMMENT '游客姓名',
	`cardtype` VARCHAR(255) NULL DEFAULT '0' COMMENT '证件类型',
	`carnumber` VARCHAR(255) NULL DEFAULT '0' COMMENT '证件号码',
	`mobile` VARCHAR(15) NULL DEFAULT '0' COMMENT '手机',
	PRIMARY KEY (`id`)
)
COMMENT='订单游客表'
ENGINE=MyISAM;";
    $sql6 = "CREATE TABLE `sline_extend_field` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`typeid` INT(11) NOT NULL DEFAULT '0' COMMENT '类别',
	`fieldname` VARCHAR(50) NOT NULL DEFAULT '0' COMMENT '字段名称',
	`fieldtype` VARCHAR(50) NOT NULL DEFAULT '0' COMMENT '字段类型',
	`description` VARCHAR(50) NOT NULL DEFAULT '0' COMMENT '字段描述',
	`tips` VARCHAR(255) NOT NULL DEFAULT '0' COMMENT '填写描述',
	`isopen` INT(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT '是否可用',
	`addtime` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '添加时间',
	`modtime` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '修改时间',
	`isunique` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '是否唯一',
	PRIMARY KEY (`id`)
)
COMMENT='产品字段扩展表'
COLLATE='utf8_general_ci'
ENGINE=InnoDB;";
    $sql7 = "ALTER TABLE `sline_spot_ticket` ADD COLUMN `number` INT NULL DEFAULT -1 COMMENT '库存'";

    if(!checkColumn('sline_member_order','remark'))
    {
        $dsql->ExecuteNoneQuery($sql1);
    }
    if(!checkColumn('sline_member_order','pid'))
    {
        $dsql->ExecuteNoneQuery($sql2);
    }
    $dsql->ExecuteNoneQuery($sql3);
    $dsql->ExecuteNoneQuery($sql4);

    if(!checkTable('sline_member_order_tourer'))
    {
        $dsql->ExecNoneQuery($sql5);
    }
    if(!checkTable('sline_extend_field'))
    {
        $dsql->ExecNoneQuery($sql6);
    }
    if(!checkColumn('sline_spot_ticket','number'))
    {
        $dsql->ExecuteNoneQuery($sql7);
    }






}
function checkColumn($table,$column)
{
    global $dsql;
    $sql = "show columns from `{$table}` like '$column'";
    $row = $dsql->GetOne($sql);
    return isset($row['Field']) ? 1 : 0;
}

function checkTable($table)
{
    global $dsql;
    $sql = "SHOW TABLES LIKE '$table'";
    $row = $dsql->GetOne($sql);
    return count($row) ? 1 : 0;

}












