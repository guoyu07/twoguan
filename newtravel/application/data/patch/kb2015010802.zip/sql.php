<?php
require_once(dirname(__FILE__) . "/include/common.inc.php");
require_once(dirname(__FILE__)."/include/file.class.php");

$dsql->safeCheck = false; //关闭安全检查
addTable();
//updateLinePrice();
modifyHtaccess();

/*function sqlModify()
{
    global $dsql;
    $sql1 = "INSERT INTO `sline_advertise_type` VALUES (45,'0','手机首页轮播广告','MobileIndexRollAd',320,200,1,0,1416981629);";
    $dsql->ExecuteNoneQuery($sql1);
}*/

//增加伪静态规则
function modifyHtaccess()
{
    $ifile = new STFile('.htaccess','r');
    $content=$ifile->readcontent();//获取文件内容
    $ifile->closefile();//文件关闭
    $ifiles = new STFile('./.htaccess','w');
    $replace = array();
    $replace[]="RewriteCond $1 !^(stourtravel|visa|cars|lines|spots|raiders|servers|uploads|photos|hotels|questions|destination|min|sline|member|tuan|customize|install|zhuanti)";
   // $replace[]="RewriteRule ^tuan/([a-z0-9]+)-([0-9_]+)-([0-9]+)$ tuan/index.php?dest_id=$1&attrid=$2&pageno=$3";
   // $replace[]="RewriteRule ^tuan/([a-z0-9]+)(/)?$ tuan/index.php?dest_id=$1";
    $new = array();
    $new[] = "RewriteCond $1 !^(stourtravel|visa|cars|lines|spots|raiders|servers|uploads|photos|hotels|questions|destination|min|sline|member|tuan|customize|install|zhuanti|ticket)";
    $new[] = "RewriteRule ^tuan/([a-z0-9]+)-([0-9]+)-([0-9_]+)-([0-9]+)$ tuan/index.php?dest_id=$1&status=$2&attrid=$3&pageno=$4";
   // $new[] = "RewriteRule ^tuan/([a-z0-9]+)(/)?$ tuan/index.php?dest_id=$1";
    $content = str_replace($replace,$new,$content);
    $ifiles->writefile($content);

}

function addTable()
{
    global $dsql;
    $sqllist="
    CREATE TABLE `sline_extend_field` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`typeid` INT(11) NOT NULL DEFAULT '0' COMMENT '类别',
	`fieldname` VARCHAR(50) NOT NULL DEFAULT '0' COMMENT '字段名称',
	`fieldtype` VARCHAR(50) NOT NULL DEFAULT '0' COMMENT '字段类型',
	`description` VARCHAR(50) NOT NULL DEFAULT '0' COMMENT '字段描述',
	`tips` VARCHAR(255) NOT NULL DEFAULT '0' COMMENT '填写描述',
	`isopen` INT(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT '是否可用',
	`addtime` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '添加时间',
	`modtime` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '修改时间',
	`isunique` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '是否唯一',
	PRIMARY KEY (`id`)
)
COMMENT='产品字段扩展表'
COLLATE='utf8_general_ci'
ENGINE=InnoDB;

";
    $sqlArr = explode(';',$sqllist);

    foreach($sqlArr as $sql)
    {
        $dsql->ExecuteNoneQuery($sql);
    }





}












