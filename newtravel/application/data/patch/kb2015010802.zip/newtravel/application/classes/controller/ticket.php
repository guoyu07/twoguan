<?php defined('SYSPATH') or die('No direct script access.');
class Controller_Ticket  extends Stourweb_Controller{
    public function before()
    {
        parent::before();
        $action = $this->request->action();

        if($action == 'list')
        {

            $param = $this->params['action'];
            $right = array(
                'read'=>'slook',
                'save'=>'smodify',
                'delete'=>'sdelete',
                'update'=>'smodify'
            );
            $user_action = $right[$param];
            if(!empty($user_action))
                Common::getUserRight('ticket',$user_action);


        }



        $this->assign('parentkey',$this->params['parentkey']);
        $this->assign('itemid',$this->params['itemid']);
        $this->assign('weblist',Common::getWebList());

    }

    //ctrip接口配置
    public function action_ctrip()
    {
        $this->display('stourtravel/ticket/ctrip');
    }



}