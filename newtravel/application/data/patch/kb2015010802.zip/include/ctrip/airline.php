<?php return array (
  '3U' => 
  array (
    'AirLine' => '3U',
    'AirLineCode' => '876',
    'AirLineName' => '四川航空股份有限公司',
    'AirLineEName' => 'Sichuan Airlines',
    'ShortName' => '四川航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '5M' => 
  array (
    'AirLine' => '5M',
    'AirLineCode' => '000',
    'AirLineName' => '美佳航空',
    'AirLineEName' => 'MEGA MALDIVES AIRLINE',
    'ShortName' => '美佳航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'NOR',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '6A' => 
  array (
    'AirLine' => '6A',
    'AirLineCode' => '095',
    'AirLineName' => '阿维亚克萨航空公司',
    'AirLineEName' => 'Aviacsa airlines',
    'ShortName' => '哈维亚克萨',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '6U' => 
  array (
    'AirLine' => '6U',
    'AirLineCode' => '891',
    'AirLineName' => '乌克兰航空公司',
    'AirLineEName' => 'Air Ukraine',
    'ShortName' => '乌克兰航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '7P' => 
  array (
    'AirLine' => '7P',
    'AirLineCode' => '000',
    'AirLineName' => '印尼巴达维亚航空公司',
    'AirLineEName' => 'Batavia Air',
    'ShortName' => '安帕国际航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '8C' => 
  array (
    'AirLine' => '8C',
    'AirLineCode' => '883',
    'AirLineName' => '东星航空有限公司',
    'AirLineEName' => 'East Star Airlines',
    'ShortName' => '东星航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '8G' => 
  array (
    'AirLine' => '8G',
    'AirLineCode' => '000',
    'AirLineName' => '安琪尔航空公司',
    'AirLineEName' => 'Angel Airlines',
    'ShortName' => '安琪尔航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '8L' => 
  array (
    'AirLine' => '8L',
    'AirLineCode' => '859',
    'AirLineName' => '云南祥鹏航空有限责任公司',
    'AirLineEName' => 'Lucky Air',
    'ShortName' => '祥鹏航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '9Q' => 
  array (
    'AirLine' => '9Q',
    'AirLineCode' => '000',
    'AirLineName' => '泰国金狮航空公司',
    'AirLineEName' => 'PB Air',
    'ShortName' => '金狮航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '9W' => 
  array (
    'AirLine' => '9W',
    'AirLineCode' => '589',
    'AirLineName' => '印度捷特航空公司',
    'AirLineEName' => 'Jet Airways India',
    'ShortName' => '印度捷特',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '9Y' => 
  array (
    'AirLine' => '9Y',
    'AirLineCode' => '000',
    'AirLineName' => '哈萨克斯坦航空公司',
    'AirLineEName' => 'Air Kazakhstan',
    'ShortName' => '哈萨克斯坦航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'A7' => 
  array (
    'AirLine' => 'A7',
    'AirLineCode' => '000',
    'AirLineName' => '西班牙红风筝航空公司',
    'AirLineEName' => 'Brymon Airways',
    'ShortName' => '普卢斯科梅特',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'AA' => 
  array (
    'AirLine' => 'AA',
    'AirLineCode' => '001',
    'AirLineName' => '美国航空公司',
    'AirLineEName' => 'American Airlines',
    'ShortName' => '美国航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'AB' => 
  array (
    'AirLine' => 'AB',
    'AirLineCode' => '745',
    'AirLineName' => '柏林航空',
    'AirLineEName' => 'Air Berlin',
    'ShortName' => '柏林航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'AC' => 
  array (
    'AirLine' => 'AC',
    'AirLineCode' => '014',
    'AirLineName' => '加拿大航空公司',
    'AirLineEName' => 'Air Canada',
    'ShortName' => '加拿大航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'https://res.aircanada.com/oci/start?_flowExecutionKey=_c33B34C62-280B-FFE1-01B5-76C18286B125_k20DE9F76-8B1A-B596-9B5B-D109E6B247CC',
  ),
  'AF' => 
  array (
    'AirLine' => 'AF',
    'AirLineCode' => '057',
    'AirLineName' => '法国航空公司',
    'AirLineEName' => 'Air France',
    'ShortName' => '法国航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'http://www.airfrance.com.cn/cgi-bin/AF/CN/zh/common/home/home/HomePageAction.do',
  ),
  'AI' => 
  array (
    'AirLine' => 'AI',
    'AirLineCode' => '098',
    'AirLineName' => '印度航空公司',
    'AirLineEName' => 'Air India',
    'ShortName' => '印度航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'AM' => 
  array (
    'AirLine' => 'AM',
    'AirLineCode' => '139',
    'AirLineName' => '墨西哥航空公司',
    'AirLineEName' => 'Aeromexico Aerovias De Mexico',
    'ShortName' => '墨西哥航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'AN' => 
  array (
    'AirLine' => 'AN',
    'AirLineCode' => '090',
    'AirLineName' => '澳大利亚安赛特航空公司',
    'AirLineEName' => 'Ansett Australia',
    'ShortName' => '安赛特航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'AP' => 
  array (
    'AirLine' => 'AP',
    'AirLineCode' => '000',
    'AirLineName' => '波利尼西亚航空公司',
    'AirLineEName' => 'Air One',
    'ShortName' => '波利尼西亚航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'AR' => 
  array (
    'AirLine' => 'AR',
    'AirLineCode' => '044',
    'AirLineName' => '阿根廷航空公司',
    'AirLineEName' => 'Aerolineas Argentinas',
    'ShortName' => '阿根廷航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'AS' => 
  array (
    'AirLine' => 'AS',
    'AirLineCode' => '027',
    'AirLineName' => '阿拉斯加航空公司',
    'AirLineEName' => 'Alaska Airlines',
    'ShortName' => '阿拉斯加航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'AY' => 
  array (
    'AirLine' => 'AY',
    'AirLineCode' => '105',
    'AirLineName' => '芬兰航空公司',
    'AirLineEName' => 'Finnair',
    'ShortName' => '芬兰航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'AZ' => 
  array (
    'AirLine' => 'AZ',
    'AirLineCode' => '055',
    'AirLineName' => '意大利航空公司',
    'AirLineEName' => 'Alitalia',
    'ShortName' => '意大利航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'https://check-in.alitalia.com/webcheckin/EN_EN/NewCheckIn/Search',
  ),
  'BA' => 
  array (
    'AirLine' => 'BA',
    'AirLineCode' => '125',
    'AirLineName' => '英国航空公司',
    'AirLineEName' => 'British Airways',
    'ShortName' => '英国航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'BC' => 
  array (
    'AirLine' => 'BC',
    'AirLineCode' => '000',
    'AirLineName' => '布利蒙航空公司',
    'AirLineEName' => 'SEABORNE AVIATION',
    'ShortName' => '布利蒙航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'BD' => 
  array (
    'AirLine' => 'BD',
    'AirLineCode' => '000',
    'AirLineName' => '英国米特兰航空',
    'AirLineEName' => 'British Midland',
    'ShortName' => '米特兰航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'BI' => 
  array (
    'AirLine' => 'BI',
    'AirLineCode' => '672',
    'AirLineName' => '汶莱皇家航空公司',
    'AirLineEName' => 'Royal Brunei Airlines',
    'ShortName' => '汶莱皇家航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'BK' => 
  array (
    'AirLine' => 'BK',
    'AirLineCode' => '866',
    'AirLineName' => '奥凯航空有限公司',
    'AirLineEName' => 'Okay Airways',
    'ShortName' => '奥凯航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'BR' => 
  array (
    'AirLine' => 'BR',
    'AirLineCode' => '695',
    'AirLineName' => '台湾长荣航公司',
    'AirLineEName' => 'EVA Airways',
    'ShortName' => '长荣航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'BT' => 
  array (
    'AirLine' => 'BT',
    'AirLineCode' => '000',
    'AirLineName' => 'Saltic航空公司',
    'AirLineEName' => 'Air Baltic',
    'ShortName' => '赛提克航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'BV' => 
  array (
    'AirLine' => 'BV',
    'AirLineCode' => '000',
    'AirLineName' => '博普航空公司（南非）',
    'AirLineEName' => 'Blue Panorama Airlines S.p.A.',
    'ShortName' => '博普航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'CA' => 
  array (
    'AirLine' => 'CA',
    'AirLineCode' => '999',
    'AirLineName' => '中国国际航空股份有限公司',
    'AirLineEName' => 'Air China',
    'ShortName' => '中国国航',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'http://www.airchina.com.cn/www/html/index/index.shtml?smartID=30511317064',
  ),
  'CI' => 
  array (
    'AirLine' => 'CI',
    'AirLineCode' => '297',
    'AirLineName' => '中华航空公司',
    'AirLineEName' => 'China Airlines',
    'ShortName' => '中华航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'CN' => 
  array (
    'AirLine' => 'CN',
    'AirLineCode' => '895',
    'AirLineName' => '大新华航空有限公司',
    'AirLineEName' => 'GRAND CHINA AIR',
    'ShortName' => '大新华',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'CO' => 
  array (
    'AirLine' => 'CO',
    'AirLineCode' => '005',
    'AirLineName' => '美国大陆航空公司',
    'AirLineEName' => 'Continental Airlines',
    'ShortName' => '美国大陆航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'https://www.continental.com/travel/checkin/start.aspx?SID=3AE4B8FD944A4B1F8F5F08293DC4AEEF&LangCode=zh-CN',
  ),
  'CP' => 
  array (
    'AirLine' => 'CP',
    'AirLineCode' => '003',
    'AirLineName' => '加拿大国际航空公司',
    'AirLineEName' => 'Canadian Airlines International',
    'ShortName' => '加拿大国际航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'CX' => 
  array (
    'AirLine' => 'CX',
    'AirLineCode' => '160',
    'AirLineName' => '国泰航空公司',
    'AirLineEName' => 'Cathay Pacific Airways',
    'ShortName' => '国泰航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'http://www.cathaypacific.com/icheckin2/forMLC.do?action=Checked&user=0&source=WEB&exitAction=&userType=member&',
  ),
  'CZ' => 
  array (
    'AirLine' => 'CZ',
    'AirLineCode' => '784',
    'AirLineName' => '中国南方航空股份有限公司',
    'AirLineEName' => 'China Southern Airlines',
    'ShortName' => '南方航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'http://airport.csair.com/cki/app',
  ),
  'DA' => 
  array (
    'AirLine' => 'DA',
    'AirLineCode' => '000',
    'AirLineName' => '达恩空中服务公司（英国）',
    'AirLineEName' => 'AIR GEORGIA',
    'ShortName' => '达恩航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'DL' => 
  array (
    'AirLine' => 'DL',
    'AirLineCode' => '006',
    'AirLineName' => '美国达美航空公司',
    'AirLineEName' => 'Delta Air Lines',
    'ShortName' => '达美航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'http://zh.delta.com/index.jsp?lang=zh&loc=cn',
  ),
  'E5' => 
  array (
    'AirLine' => 'E5',
    'AirLineCode' => '000',
    'AirLineName' => '萨马拉航空公司',
    'AirLineEName' => 'Samara Airlines',
    'ShortName' => '萨马拉航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'EF' => 
  array (
    'AirLine' => 'EF',
    'AirLineCode' => '000',
    'AirLineName' => '远东航空运输公司（中国台湾）',
    'AirLineEName' => 'Far Eastern Air Transport',
    'ShortName' => '远东航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'EK' => 
  array (
    'AirLine' => 'EK',
    'AirLineCode' => '176',
    'AirLineName' => '阿联酋国际航空公司',
    'AirLineEName' => 'Emirates',
    'ShortName' => '阿联酋航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'ET' => 
  array (
    'AirLine' => 'ET',
    'AirLineCode' => '071',
    'AirLineName' => '埃塞俄比亚航空公司',
    'AirLineEName' => 'Ethiopian Airlines',
    'ShortName' => '埃塞俄比亚航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'EU' => 
  array (
    'AirLine' => 'EU',
    'AirLineCode' => '811',
    'AirLineName' => '成都航空有限公司',
    'AirLineEName' => 'United Eagle Airlines',
    'ShortName' => '成都航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'EY' => 
  array (
    'AirLine' => 'EY',
    'AirLineCode' => '607',
    'AirLineName' => '阿联酋阿提哈德航空',
    'AirLineEName' => 'ETIHAD AIRWAYS',
    'ShortName' => '阿提哈德',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => ' http://www.etihadairways.com/sites/etihad/cn/zh/home/pages/home.aspx',
  ),
  'FD' => 
  array (
    'AirLine' => 'FD',
    'AirLineCode' => '000',
    'AirLineName' => '泰国亚洲航空公司',
    'AirLineEName' => 'Thai AirAsia',
    'ShortName' => '泰国亚洲',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'FI' => 
  array (
    'AirLine' => 'FI',
    'AirLineCode' => '000',
    'AirLineName' => '冰岛航空公司',
    'AirLineEName' => 'Icelandic Airlines Ltd',
    'ShortName' => '冰岛航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'NOR',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'FM' => 
  array (
    'AirLine' => 'FM',
    'AirLineCode' => '774',
    'AirLineName' => '上海航空有限公司',
    'AirLineEName' => 'Shanghai Airlines',
    'ShortName' => '上海航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'http://www.shanghai-air.com/PublicService/OnlineCheckIn.aspx',
  ),
  'FT' => 
  array (
    'AirLine' => 'FT',
    'AirLineCode' => '084',
    'AirLineName' => '暹粒航空公司',
    'AirLineEName' => 'Siem Reap Airways International',
    'ShortName' => '暹粒航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'FV' => 
  array (
    'AirLine' => 'FV',
    'AirLineCode' => '195',
    'AirLineName' => '俄罗斯普尔科沃航空公司',
    'AirLineEName' => 'ROSSIYA-RUSSIAN AIRLINES',
    'ShortName' => '普尔科沃航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'G5' => 
  array (
    'AirLine' => 'G5',
    'AirLineCode' => '987',
    'AirLineName' => '华夏航空有限公司',
    'AirLineEName' => 'China　Express　Airlines',
    'ShortName' => '华夏航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'GA' => 
  array (
    'AirLine' => 'GA',
    'AirLineCode' => '126',
    'AirLineName' => '印度尼西亚鹰航公司',
    'AirLineEName' => 'Garuda Indonesia',
    'ShortName' => '印尼鹰航航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'GE' => 
  array (
    'AirLine' => 'GE',
    'AirLineCode' => '170',
    'AirLineName' => '台湾复兴航空公司',
    'AirLineEName' => 'TransAsia Airways',
    'ShortName' => '复兴航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'GF' => 
  array (
    'AirLine' => 'GF',
    'AirLineCode' => '072',
    'AirLineName' => '海湾航空公司',
    'AirLineEName' => 'GULF AIR',
    'ShortName' => '海湾航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'GS' => 
  array (
    'AirLine' => 'GS',
    'AirLineCode' => '826',
    'AirLineName' => '天津航空有限责任公司',
    'AirLineEName' => 'TIANJIN AIRLINES',
    'ShortName' => '天津航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'H8' => 
  array (
    'AirLine' => 'H8',
    'AirLineCode' => '000',
    'AirLineName' => '俄罗斯远东(阿巴罗夫斯克)航空公司',
    'AirLineEName' => 'Dalavia-Far East Airways (Russian Federation)',
    'ShortName' => '远东航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'HO' => 
  array (
    'AirLine' => 'HO',
    'AirLineCode' => '018',
    'AirLineName' => '上海吉祥航空股份有限公司',
    'AirLineEName' => 'Juneyao Airlines',
    'ShortName' => '吉祥航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'HU' => 
  array (
    'AirLine' => 'HU',
    'AirLineCode' => '880',
    'AirLineName' => '海南航空股份有限公司',
    'AirLineEName' => 'Hainan Airlines',
    'ShortName' => '海南航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => ' http://www.hnair.com/',
  ),
  'HX' => 
  array (
    'AirLine' => 'HX',
    'AirLineCode' => '851',
    'AirLineName' => '香港航空公司',
    'AirLineEName' => 'Hong Kong Airlines',
    'ShortName' => '香港航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 'http://www.hongkongexpress.com/fscheduleSearch!turnCheckIn.action?pMenuName=book_manage&country_code=HK&request_locale=zh_TW',
  ),
  'HY' => 
  array (
    'AirLine' => 'HY',
    'AirLineCode' => '250',
    'AirLineName' => '乌兹别克斯坦航空公司',
    'AirLineEName' => 'Uzbekistan Airways',
    'ShortName' => '乌兹别克斯坦航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'IB' => 
  array (
    'AirLine' => 'IB',
    'AirLineCode' => '075',
    'AirLineName' => '西班牙航空公司',
    'AirLineEName' => 'Iberia Airlines',
    'ShortName' => '西班牙航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'IC' => 
  array (
    'AirLine' => 'IC',
    'AirLineCode' => '058',
    'AirLineName' => '印度航空公司',
    'AirLineEName' => 'IAC Indian Airlines',
    'ShortName' => '印度航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'IR' => 
  array (
    'AirLine' => 'IR',
    'AirLineCode' => '096',
    'AirLineName' => '伊朗航空公司',
    'AirLineEName' => 'Iran Air',
    'ShortName' => '伊朗航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'IV' => 
  array (
    'AirLine' => 'IV',
    'AirLineCode' => '791',
    'AirLineName' => '意大利风航',
    'AirLineEName' => 'Wind Jet',
    'ShortName' => '福建航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'IW' => 
  array (
    'AirLine' => 'IW',
    'AirLineCode' => '000',
    'AirLineName' => '密涅瓦法国空运公司（法国）',
    'AirLineEName' => 'AOM French Airlines',
    'ShortName' => '密涅瓦航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'J2' => 
  array (
    'AirLine' => 'J2',
    'AirLineCode' => '000',
    'AirLineName' => '阿塞拜疆航空公司',
    'AirLineEName' => 'Azerbaijan  Airlines',
    'ShortName' => '阿塞拜疆航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'JD' => 
  array (
    'AirLine' => 'JD',
    'AirLineCode' => '898',
    'AirLineName' => '北京首都航空有限公司',
    'AirLineEName' => 'Dear Air',
    'ShortName' => '首都航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'JK' => 
  array (
    'AirLine' => 'JK',
    'AirLineCode' => '000',
    'AirLineName' => '斯潘航空公司',
    'AirLineEName' => 'Spanair S.A.',
    'ShortName' => '斯潘航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'JL' => 
  array (
    'AirLine' => 'JL',
    'AirLineCode' => '131',
    'AirLineName' => '日本航空公司',
    'AirLineEName' => 'Japan Airlines',
    'ShortName' => '日本航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'http://www.cn.jal.com/world/common/script/frameset/?programPath=https%3A%2F%2Fwww.5931.jal.co.jp%2FrsvInter%2FLoginPageDisp.do&PRM_COUNTRY_CD=CN&PRM_SITE=AS2&PRM_LANGUAGE=ENG&x=148&y=17',
  ),
  'JR' => 
  array (
    'AirLine' => 'JR',
    'AirLineCode' => '929',
    'AirLineName' => '幸福航空有限责任公司',
    'AirLineEName' => 'JOY AIR CO',
    'ShortName' => '幸福航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'JS' => 
  array (
    'AirLine' => 'JS',
    'AirLineCode' => '120',
    'AirLineName' => '朝鲜航空公司',
    'AirLineEName' => 'Air Koryo',
    'ShortName' => '朝鲜航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'JU' => 
  array (
    'AirLine' => 'JU',
    'AirLineCode' => '000',
    'AirLineName' => '南斯拉夫航空公司',
    'AirLineEName' => 'JAT Yugoslav Airlines',
    'ShortName' => '南斯拉夫航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'K2' => 
  array (
    'AirLine' => 'K2',
    'AirLineCode' => '000',
    'AirLineName' => '吉尔吉斯坦航空公司',
    'AirLineEName' => 'Kyrgyzstan Airlines',
    'ShortName' => '吉尔吉斯坦航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'KA' => 
  array (
    'AirLine' => 'KA',
    'AirLineCode' => '043',
    'AirLineName' => '港龙航空公司',
    'AirLineEName' => 'Dragonair',
    'ShortName' => '港龙航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'http://www.dragonair.com/kaicheckin2/forMLC.do?action=Checked&COUNTRY=INTL&type=nonMember&appcode=KA&source=WEB&',
  ),
  'KC' => 
  array (
    'AirLine' => 'KC',
    'AirLineCode' => '465',
    'AirLineName' => '哈萨克斯坦阿斯塔纳航空公司',
    'AirLineEName' => 'Air Astana',
    'ShortName' => '阿斯塔纳',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'KE' => 
  array (
    'AirLine' => 'KE',
    'AirLineCode' => '180',
    'AirLineName' => '大韩航空公司',
    'AirLineEName' => 'Korean Air',
    'ShortName' => '大韩航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'KF' => 
  array (
    'AirLine' => 'KF',
    'AirLineCode' => '142',
    'AirLineName' => '蓝天航空公司',
    'AirLineEName' => 'Blue1',
    'ShortName' => '蓝天航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'KL' => 
  array (
    'AirLine' => 'KL',
    'AirLineCode' => '074',
    'AirLineName' => '荷兰皇家航空公司',
    'AirLineEName' => 'KLM Royal Dutch Airlines',
    'ShortName' => '荷兰皇家',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => ' http://www.klm.com/travel/cn_cn/index.htm#tab=db_ici',
  ),
  'KN' => 
  array (
    'AirLine' => 'KN',
    'AirLineCode' => '822',
    'AirLineName' => '中国联合航空有限公司',
    'AirLineEName' => 'China United Airlines',
    'ShortName' => '中国联航',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'KQ' => 
  array (
    'AirLine' => 'KQ',
    'AirLineCode' => '706',
    'AirLineName' => '肯尼亚航空公司',
    'AirLineEName' => 'Kenya Airways',
    'ShortName' => '肯尼亚航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'www.kenya-airways.com',
  ),
  'KU' => 
  array (
    'AirLine' => 'KU',
    'AirLineCode' => '229',
    'AirLineName' => '科威特航空公司',
    'AirLineEName' => 'Kuwait Airways',
    'ShortName' => '科威特航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'KY' => 
  array (
    'AirLine' => 'KY',
    'AirLineCode' => '833',
    'AirLineName' => '昆明航空有限公司',
    'AirLineEName' => 'KUNMING AIR',
    'ShortName' => '昆明航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'LA' => 
  array (
    'AirLine' => 'LA',
    'AirLineCode' => '045',
    'AirLineName' => '智利国家航空公司',
    'AirLineEName' => 'Lan Chile Airlines',
    'ShortName' => '智利航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'LH' => 
  array (
    'AirLine' => 'LH',
    'AirLineCode' => '220',
    'AirLineName' => '德国汉莎航空公司',
    'AirLineEName' => 'Lufthansa German Airlines',
    'ShortName' => '汉莎航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'LO' => 
  array (
    'AirLine' => 'LO',
    'AirLineCode' => '080',
    'AirLineName' => '波兰航空公司',
    'AirLineEName' => 'Lot-Polish Airlines',
    'ShortName' => '波兰航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'LT' => 
  array (
    'AirLine' => 'LT',
    'AirLineCode' => '266',
    'AirLineName' => '温特内曼国际航空公司',
    'AirLineEName' => 'LTU International Airways',
    'ShortName' => '温特内曼航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'LX' => 
  array (
    'AirLine' => 'LX',
    'AirLineCode' => '724',
    'AirLineName' => '瑞士国际航空公司',
    'AirLineEName' => 'Swiss International Air Lines',
    'ShortName' => '瑞士国际航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'https://booking.swiss.com/web/wci.htm?WT.ac=webcheckinHbox&WT.ad=webcheckinHbox ',
  ),
  'LY' => 
  array (
    'AirLine' => 'LY',
    'AirLineCode' => '114',
    'AirLineName' => '以色列航空公司',
    'AirLineEName' => 'EL AL Israel Airlines',
    'ShortName' => '以色列航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'MA' => 
  array (
    'AirLine' => 'MA',
    'AirLineCode' => '182',
    'AirLineName' => '匈牙利航空公司',
    'AirLineEName' => 'Malev-Hungarian Airlines',
    'ShortName' => '匈牙利航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'MD' => 
  array (
    'AirLine' => 'MD',
    'AirLineCode' => '258',
    'AirLineName' => '马达加斯加航空',
    'AirLineEName' => 'Societe Nationale Malgache de Transports',
    'ShortName' => '马达加斯加',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'MF' => 
  array (
    'AirLine' => 'MF',
    'AirLineCode' => '731',
    'AirLineName' => '厦门航空有限公司',
    'AirLineEName' => 'Xiamen Airlines',
    'ShortName' => '厦门航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'http://www.xiamenair.com.cn/#this',
  ),
  'MH' => 
  array (
    'AirLine' => 'MH',
    'AirLineCode' => '232',
    'AirLineName' => '马来西亚航空公司',
    'AirLineEName' => 'Malaysia Airlines',
    'ShortName' => '马来西亚航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'https://fastcheck.sita.aero/cce-presentation-web-mh/entryUpdate.do',
  ),
  'MI' => 
  array (
    'AirLine' => 'MI',
    'AirLineCode' => '629',
    'AirLineName' => '新加坡胜安航空公司',
    'AirLineEName' => 'SilkAir',
    'ShortName' => '新加坡胜安航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'MP' => 
  array (
    'AirLine' => 'MP',
    'AirLineCode' => '000',
    'AirLineName' => '荷兰马丁航空公司',
    'AirLineEName' => 'Martinair Holland',
    'ShortName' => '荷兰马丁航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'MS' => 
  array (
    'AirLine' => 'MS',
    'AirLineCode' => '077',
    'AirLineName' => '埃及航空公司',
    'AirLineEName' => 'Egypt Air',
    'ShortName' => '埃及航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'MU' => 
  array (
    'AirLine' => 'MU',
    'AirLineCode' => '781',
    'AirLineName' => '中国东方航空股份有限公司',
    'AirLineEName' => 'China Eastern Airlines',
    'ShortName' => '东方航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'http://www.ce-air.com/mu/front/cuss/cuss!doInit.shtml',
  ),
  'MX' => 
  array (
    'AirLine' => 'MX',
    'AirLineCode' => '000',
    'AirLineName' => '墨西哥航空公司',
    'AirLineEName' => 'Mexicana',
    'ShortName' => '墨西哥航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'NH' => 
  array (
    'AirLine' => 'NH',
    'AirLineCode' => '205',
    'AirLineName' => '全日本空输株式会社',
    'AirLineEName' => 'All Nippon Airways',
    'ShortName' => '全日空航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'https://aswbe-i.ana.co.jp/p_per/sky_ip_per_jp/preSearchCheckIn.do?CONNECTION_KIND=CHN&LANG=cn',
  ),
  'NS' => 
  array (
    'AirLine' => 'NS',
    'AirLineCode' => '836',
    'AirLineName' => '河北航空有限公司',
    'AirLineEName' => 'hbairlines',
    'ShortName' => '河北航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'NU' => 
  array (
    'AirLine' => 'NU',
    'AirLineCode' => '000',
    'AirLineName' => '日本跨洋航空公司',
    'AirLineEName' => 'Japan Transocean Air',
    'ShortName' => '日本跨洋航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'NW' => 
  array (
    'AirLine' => 'NW',
    'AirLineCode' => '012',
    'AirLineName' => '美国西北航空公司',
    'AirLineEName' => 'Northwest Airlines',
    'ShortName' => '美西北航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'NX' => 
  array (
    'AirLine' => 'NX',
    'AirLineCode' => '675',
    'AirLineName' => '澳门航空公司',
    'AirLineEName' => 'Air Macau',
    'ShortName' => '澳门航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'NZ' => 
  array (
    'AirLine' => 'NZ',
    'AirLineCode' => '086',
    'AirLineName' => '新西兰航空公司',
    'AirLineEName' => 'Air New Zealand',
    'ShortName' => '新西兰航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'OA' => 
  array (
    'AirLine' => 'OA',
    'AirLineCode' => '050',
    'AirLineName' => '奥林匹克航空公司',
    'AirLineEName' => 'Olympic Airways',
    'ShortName' => '奥林匹克航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'OM' => 
  array (
    'AirLine' => 'OM',
    'AirLineCode' => '289',
    'AirLineName' => '蒙古航空公司',
    'AirLineEName' => 'MIAT Mongolian Airlines',
    'ShortName' => '蒙古航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'OS' => 
  array (
    'AirLine' => 'OS',
    'AirLineCode' => '257',
    'AirLineName' => '奥地利航空公司',
    'AirLineEName' => 'Austrian Airlines',
    'ShortName' => '奥地利航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'http://www.austrian.com/',
  ),
  'OZ' => 
  array (
    'AirLine' => 'OZ',
    'AirLineCode' => '988',
    'AirLineName' => '韩亚航空公司',
    'AirLineEName' => 'Asiana Airlines',
    'ShortName' => '韩亚航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => ' http://chkin.flyasiana.com/start/main.jsp?enType=E',
  ),
  'P7' => 
  array (
    'AirLine' => 'P7',
    'AirLineCode' => '000',
    'AirLineName' => '俄罗斯天空航空公司',
    'AirLineEName' => 'Russian Sky Airlines',
    'ShortName' => '俄东方航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'PG' => 
  array (
    'AirLine' => 'PG',
    'AirLineCode' => '829',
    'AirLineName' => '曼谷航空公司',
    'AirLineEName' => 'Bangkok Airways',
    'ShortName' => '曼谷航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'PH' => 
  array (
    'AirLine' => 'PH',
    'AirLineCode' => '000',
    'AirLineName' => '波利尼西亚航空公司',
    'AirLineEName' => 'Polynesian Airlines',
    'ShortName' => '波利尼西亚航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'PK' => 
  array (
    'AirLine' => 'PK',
    'AirLineCode' => '214',
    'AirLineName' => '巴基斯坦国际航空公司',
    'AirLineEName' => 'Pakistan International Airlines',
    'ShortName' => '巴基斯坦航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'PN' => 
  array (
    'AirLine' => 'PN',
    'AirLineCode' => '847',
    'AirLineName' => '西部航空有限责任公司',
    'AirLineEName' => 'China West Air',
    'ShortName' => '西部航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'PR' => 
  array (
    'AirLine' => 'PR',
    'AirLineCode' => '079',
    'AirLineName' => '菲律宾航空公司',
    'AirLineEName' => 'Philippine Airlines',
    'ShortName' => '菲律宾航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'QF' => 
  array (
    'AirLine' => 'QF',
    'AirLineCode' => '081',
    'AirLineName' => '澳洲航空公司',
    'AirLineEName' => 'Qantas Airways',
    'ShortName' => '澳洲航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'QR' => 
  array (
    'AirLine' => 'QR',
    'AirLineCode' => '157',
    'AirLineName' => '卡塔尔航空公司',
    'AirLineEName' => 'Qatar Airways',
    'ShortName' => '卡塔尔航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'http://www.qatarairways.com/cn/cn/homepage.html',
  ),
  'QV' => 
  array (
    'AirLine' => 'QV',
    'AirLineCode' => '627',
    'AirLineName' => '老挝航空公司',
    'AirLineEName' => 'LAO Aviation',
    'ShortName' => '老挝航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'RA' => 
  array (
    'AirLine' => 'RA',
    'AirLineCode' => '285',
    'AirLineName' => '尼泊尔航空公司',
    'AirLineEName' => 'Royal Nepal Airlines',
    'ShortName' => '尼泊尔航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'RO' => 
  array (
    'AirLine' => 'RO',
    'AirLineCode' => '281',
    'AirLineName' => '罗马尼亚航空公司',
    'AirLineEName' => 'Romanian Air Transport',
    'ShortName' => '罗马尼亚航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'S7' => 
  array (
    'AirLine' => 'S7',
    'AirLineCode' => '421',
    'AirLineName' => '俄罗斯西伯利亚航空公司',
    'AirLineEName' => 'Siberia Airlines',
    'ShortName' => '西伯利亚航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'SA' => 
  array (
    'AirLine' => 'SA',
    'AirLineCode' => '083',
    'AirLineName' => '南非航空公司',
    'AirLineEName' => 'South African Airways ',
    'ShortName' => '南非航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'SC' => 
  array (
    'AirLine' => 'SC',
    'AirLineCode' => '324',
    'AirLineName' => '山东航空股份有限公司',
    'AirLineEName' => 'Shandong Airlines',
    'ShortName' => '山东航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'SK' => 
  array (
    'AirLine' => 'SK',
    'AirLineCode' => '117',
    'AirLineName' => '北欧航空公司',
    'AirLineEName' => 'SAS-Scandinavian Airlines',
    'ShortName' => '北欧航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'SN' => 
  array (
    'AirLine' => 'SN',
    'AirLineCode' => '82 ',
    'AirLineName' => '比利时航空公司',
    'AirLineEName' => 'SAB Sabena',
    'ShortName' => '比利时航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'SQ' => 
  array (
    'AirLine' => 'SQ',
    'AirLineCode' => '618',
    'AirLineName' => '新加坡航空公司',
    'AirLineEName' => 'Singapore Airlines',
    'ShortName' => '新加坡航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'http://www.singaporeair.com/saa/zh_CN/index.jsp',
  ),
  'SR' => 
  array (
    'AirLine' => 'SR',
    'AirLineCode' => '085',
    'AirLineName' => '瑞士航空公司',
    'AirLineEName' => 'Swiss Airlines',
    'ShortName' => '瑞士航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'SU' => 
  array (
    'AirLine' => 'SU',
    'AirLineCode' => '555',
    'AirLineName' => '俄罗斯航空公司',
    'AirLineEName' => 'Aeroflot-Russian International Airlines',
    'ShortName' => '俄罗斯航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'https://checkin.sabre.com/aeroflot/selectLanguage.do?Language=en',
  ),
  'TF' => 
  array (
    'AirLine' => 'TF',
    'AirLineCode' => '000',
    'AirLineName' => '泰国飞行航空公司',
    'AirLineEName' => 'Air Transport Pyrenees',
    'ShortName' => '泰国飞行航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'TG' => 
  array (
    'AirLine' => 'TG',
    'AirLineCode' => '217',
    'AirLineName' => '泰国国际航空公司',
    'AirLineEName' => 'Thai Airways International',
    'ShortName' => '泰国国际航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'TK' => 
  array (
    'AirLine' => 'TK',
    'AirLineCode' => '235',
    'AirLineName' => '土耳其航空公司',
    'AirLineEName' => 'Turkish Airlines',
    'ShortName' => '土耳其航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'http://www.turkishairlines.com/zh-CN/index.aspx',
  ),
  'TV' => 
  array (
    'AirLine' => 'TV',
    'AirLineCode' => '088',
    'AirLineName' => '西藏航空有限公司',
    'AirLineEName' => 'China Tibetan Airlines',
    'ShortName' => '西藏航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'TW' => 
  array (
    'AirLine' => 'TW',
    'AirLineCode' => '015',
    'AirLineName' => '美国环球航空公司',
    'AirLineEName' => 'Trans World Airlines',
    'ShortName' => '环球航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'U6' => 
  array (
    'AirLine' => 'U6',
    'AirLineCode' => '262',
    'AirLineName' => '乌拉尔航空公司',
    'AirLineEName' => 'URAL AIRLINES',
    'ShortName' => '乌拉尔航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'UA' => 
  array (
    'AirLine' => 'UA',
    'AirLineCode' => '016',
    'AirLineName' => '美国联合航空公司',
    'AirLineEName' => 'United Airlines',
    'ShortName' => '联合航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'http://www.cn.united.com/core/chinese/index.html',
  ),
  'UB' => 
  array (
    'AirLine' => 'UB',
    'AirLineCode' => '209',
    'AirLineName' => '缅甸航空公司',
    'AirLineEName' => 'Myanmar Airways International',
    'ShortName' => '缅甸航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'UL' => 
  array (
    'AirLine' => 'UL',
    'AirLineCode' => '603',
    'AirLineName' => '斯里兰卡航空公司',
    'AirLineEName' => 'SriLankan Airlines',
    'ShortName' => '斯里兰卡航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'UM' => 
  array (
    'AirLine' => 'UM',
    'AirLineCode' => '168',
    'AirLineName' => '津巴布韦航空公司',
    'AirLineEName' => 'Air Zimbabwe',
    'ShortName' => '津巴布韦航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'UN' => 
  array (
    'AirLine' => 'UN',
    'AirLineCode' => '670',
    'AirLineName' => '环空航空公司',
    'AirLineEName' => 'Transaero Airlines',
    'ShortName' => '环空航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'UO' => 
  array (
    'AirLine' => 'UO',
    'AirLineCode' => '128',
    'AirLineName' => '香港快运航空公司',
    'AirLineEName' => 'Hong Kong Express Airways',
    'ShortName' => '香港快运航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'US' => 
  array (
    'AirLine' => 'US',
    'AirLineCode' => '037',
    'AirLineName' => '美国合众国航空公司',
    'AirLineEName' => 'US Airways',
    'ShortName' => '全美航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'UX' => 
  array (
    'AirLine' => 'UX',
    'AirLineCode' => '996',
    'AirLineName' => '西班牙欧洲航空公司',
    'AirLineEName' => 'Air Europa',
    'ShortName' => '西班牙欧航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'VD' => 
  array (
    'AirLine' => 'VD',
    'AirLineCode' => '981',
    'AirLineName' => '河南航空有限公司',
    'AirLineEName' => 'HE NAN AIRLINES',
    'ShortName' => '河南航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'VJ' => 
  array (
    'AirLine' => 'VJ',
    'AirLineCode' => '000',
    'AirLineName' => '柬埔寨航空公司',
    'AirLineEName' => 'Royal Air Cambodge',
    'ShortName' => '柬埔寨航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'VN' => 
  array (
    'AirLine' => 'VN',
    'AirLineCode' => '738',
    'AirLineName' => '越南航空公司',
    'AirLineEName' => 'Vietnam Airlines',
    'ShortName' => '越南航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'http://www.vietnamairlines.com/wps/portal/en/site/home?lang=en&country=china&country_code=CN&#',
  ),
  'VQ' => 
  array (
    'AirLine' => 'VQ',
    'AirLineCode' => '000',
    'AirLineName' => 'Vintage航空公司',
    'AirLineEName' => 'Vintage Props and Jets',
    'ShortName' => '文特芝航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'VS' => 
  array (
    'AirLine' => 'VS',
    'AirLineCode' => '932',
    'AirLineName' => '维珍航空公司',
    'AirLineEName' => 'Virgin Atlantic',
    'ShortName' => '维珍航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'http://www.virgin-atlantic.com/zh_cn/cn/index.jsp',
  ),
  'VV' => 
  array (
    'AirLine' => 'VV',
    'AirLineCode' => '870',
    'AirLineName' => '空中世界乌克兰航空公司',
    'AirLineEName' => 'Aerosvit Airlines',
    'ShortName' => '空中世界航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'https://fastcheck.sita.aero/cce-presentation-web-vv/entryUpdate.do',
  ),
  'X3' => 
  array (
    'AirLine' => 'X3',
    'AirLineCode' => '000',
    'AirLineName' => '贝加尔航空公司',
    'AirLineEName' => 'Baikal Airlines',
    'ShortName' => '贝加尔航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'X7' => 
  array (
    'AirLine' => 'X7',
    'AirLineCode' => '000',
    'AirLineName' => '俄罗斯赤塔航空公司',
    'AirLineEName' => 'Chita Avia',
    'ShortName' => '赤塔航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'XF' => 
  array (
    'AirLine' => 'XF',
    'AirLineCode' => '277',
    'AirLineName' => '符拉迪沃斯托克航空公司',
    'AirLineEName' => 'Vladivostok Air',
    'ShortName' => '符拉迪沃航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'YP' => 
  array (
    'AirLine' => 'YP',
    'AirLineCode' => '000',
    'AirLineName' => '劳埃德航空公司',
    'AirLineEName' => 'Aero Lloyd',
    'ShortName' => '劳埃德航航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'ZH' => 
  array (
    'AirLine' => 'ZH',
    'AirLineCode' => '479',
    'AirLineName' => '深圳航空有限责任公司',
    'AirLineEName' => 'Shenzhen Airlines',
    'ShortName' => '深圳航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 'T',
    'OnlineCheckinUrl' => 'http://www.shenzhenair.com/',
  ),
  'TR' => 
  array (
    'AirLine' => 'TR',
    'AirLineCode' => '000',
    'AirLineName' => '特里加纳航空公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '特里加纳航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'HA' => 
  array (
    'AirLine' => 'HA',
    'AirLineCode' => '173',
    'AirLineName' => '夏威夷航空公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '夏威夷航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'NOR',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '3G' => 
  array (
    'AirLine' => '3G',
    'AirLineCode' => '000',
    'AirLineName' => '大西洋航空公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '大西洋航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '5J' => 
  array (
    'AirLine' => '5J',
    'AirLineCode' => '203',
    'AirLineName' => '宿雾航空',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '宿雾航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '3K' => 
  array (
    'AirLine' => '3K',
    'AirLineCode' => '000',
    'AirLineName' => '捷星亚洲航空公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '捷星航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'QZ' => 
  array (
    'AirLine' => 'QZ',
    'AirLineCode' => '000',
    'AirLineName' => '印尼亚航',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '印尼亚航',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'NOR',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '4L' => 
  array (
    'AirLine' => '4L',
    'AirLineCode' => '000',
    'AirLineName' => '哈萨克斯坦航空公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '哈萨克斯坦',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'F6' => 
  array (
    'AirLine' => 'F6',
    'AirLineCode' => '000',
    'AirLineName' => '中国航空股份有限公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '中国航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'AH' => 
  array (
    'AirLine' => 'AH',
    'AirLineCode' => '000',
    'AirLineName' => '阿尔及利亚航空公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '阿尔及利亚航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'YX' => 
  array (
    'AirLine' => 'YX',
    'AirLineCode' => '453',
    'AirLineName' => '中西部航空',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '中西部航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '8S' => 
  array (
    'AirLine' => '8S',
    'AirLineCode' => '000',
    'AirLineName' => 'Unknown',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => 
    array (
    ),
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'S2' => 
  array (
    'AirLine' => 'S2',
    'AirLineCode' => '705',
    'AirLineName' => '撒哈拉航空',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '撒哈拉航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'AK' => 
  array (
    'AirLine' => 'AK',
    'AirLineCode' => '807',
    'AirLineName' => '亚洲航空',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '亚洲航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'B7' => 
  array (
    'AirLine' => 'B7',
    'AirLineCode' => '525',
    'AirLineName' => '立荣航空公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '立荣航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'RI' => 
  array (
    'AirLine' => 'RI',
    'AirLineCode' => '000',
    'AirLineName' => 'Unknown',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => 
    array (
    ),
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'NOR',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'IT' => 
  array (
    'AirLine' => 'IT',
    'AirLineCode' => '090',
    'AirLineName' => '印度翠鸟航空公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '印度翠鸟航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'D7' => 
  array (
    'AirLine' => 'D7',
    'AirLineCode' => '000',
    'AirLineName' => '亚航 X',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '亚航 X',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'NOR',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'J8' => 
  array (
    'AirLine' => 'J8',
    'AirLineCode' => '000',
    'AirLineName' => '成功航空公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '成功航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '7C' => 
  array (
    'AirLine' => '7C',
    'AirLineCode' => '000',
    'AirLineName' => 'Unknown',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => 
    array (
    ),
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'NOR',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'OX' => 
  array (
    'AirLine' => 'OX',
    'AirLineCode' => '578',
    'AirLineName' => '泰国东方航空公司 ',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '泰国东方',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'IY' => 
  array (
    'AirLine' => 'IY',
    'AirLineCode' => '635',
    'AirLineName' => '也门航空',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '也门航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'NOR',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'Z2' => 
  array (
    'AirLine' => 'Z2',
    'AirLineCode' => '000',
    'AirLineName' => '菲律宾飞龙航空 ',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '菲律宾飞龙',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '8M' => 
  array (
    'AirLine' => '8M',
    'AirLineCode' => '000',
    'AirLineName' => 'Unknown',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => 
    array (
    ),
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'NOR',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'JQ' => 
  array (
    'AirLine' => 'JQ',
    'AirLineCode' => '041',
    'AirLineName' => '捷星航空',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '捷星航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '9C' => 
  array (
    'AirLine' => '9C',
    'AirLineCode' => '000',
    'AirLineName' => '春秋航空',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '春秋航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'HQ' => 
  array (
    'AirLine' => 'HQ',
    'AirLineCode' => '000',
    'AirLineName' => '商务捷运航空公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '捷运航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  '8U' => 
  array (
    'AirLine' => '8U',
    'AirLineCode' => '000',
    'AirLineName' => 'Unknown',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => 
    array (
    ),
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'MZ' => 
  array (
    'AirLine' => 'MZ',
    'AirLineCode' => '621',
    'AirLineName' => '美派蒂航空公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '美派蒂航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'TH' => 
  array (
    'AirLine' => 'TH',
    'AirLineCode' => '000',
    'AirLineName' => '金鹏航空公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '金鹏航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'DJ' => 
  array (
    'AirLine' => 'DJ',
    'AirLineCode' => '856',
    'AirLineName' => '维尔京蓝航空',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '维尔京蓝航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'WN' => 
  array (
    'AirLine' => 'WN',
    'AirLineCode' => '526',
    'AirLineName' => '西南航空',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '西南航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'MK' => 
  array (
    'AirLine' => 'MK',
    'AirLineCode' => '239',
    'AirLineName' => '毛里求斯航空公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '毛里求斯航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'AO' => 
  array (
    'AirLine' => 'AO',
    'AirLineCode' => '000',
    'AirLineName' => '澳亚航空公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '澳亚航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'JO' => 
  array (
    'AirLine' => 'JO',
    'AirLineCode' => '708',
    'AirLineName' => '日线航空',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '日线航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'OQ' => 
  array (
    'AirLine' => 'OQ',
    'AirLineCode' => '000',
    'AirLineName' => '重庆航空有限责任公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '重庆航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'AE' => 
  array (
    'AirLine' => 'AE',
    'AirLineCode' => '803',
    'AirLineName' => '华信航空',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '华信航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'DT' => 
  array (
    'AirLine' => 'DT',
    'AirLineCode' => '000',
    'AirLineName' => '安哥拉航空公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => 
    array (
    ),
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'TN' => 
  array (
    'AirLine' => 'TN',
    'AirLineCode' => '244',
    'AirLineName' => '大溪地航空公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '大溪地',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'WY' => 
  array (
    'AirLine' => 'WY',
    'AirLineCode' => '000',
    'AirLineName' => 'Unknown',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => 
    array (
    ),
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'NOR',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'RJ' => 
  array (
    'AirLine' => 'RJ',
    'AirLineCode' => '000',
    'AirLineName' => '约旦王家航空公司',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '约旦王家',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'LJ' => 
  array (
    'AirLine' => 'LJ',
    'AirLineCode' => '000',
    'AirLineName' => '塞拉里昂航空公司 ',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '塞拉里昂航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'NOR',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
  'SV' => 
  array (
    'AirLine' => 'SV',
    'AirLineCode' => '065',
    'AirLineName' => '沙特航空',
    'AirLineEName' => 
    array (
    ),
    'ShortName' => '沙特航空',
    'GroupId' => '0',
    'GroupName' => 
    array (
    ),
    'StrictType' => 'HGH',
    'AddonPriceProtected' => 'false',
    'IsSupportAirPlus' => 
    array (
    ),
    'OnlineCheckinUrl' => 
    array (
    ),
  ),
);