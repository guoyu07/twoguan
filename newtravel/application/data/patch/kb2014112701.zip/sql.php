<?php
require_once(dirname(__FILE__) . "/include/common.inc.php");

$dsql->safeCheck = false; //关闭安全检查
sqlModify();


function sqlModify()
{
    global $dsql;
    $sql1 = "INSERT INTO `sline_advertise_type` VALUES (45,'0','手机首页轮播广告','MobileIndexRollAd',320,200,1,0,1416981629);";
    $dsql->ExecuteNoneQuery($sql1);
}












